/* v2 App shell：桌機優先 · 選定方向 · 狀態分頁 */
const V2_PAGES = [
  window.V2_shared, window.V2_auth, window.V2_index, window.V2_explore,
  window.V2_detail, window.V2_profile, window.V2_admin
];
const V2_LABELS = ["共用元件", "登入/註冊", "首頁", "探索（搜尋＋地圖）", "詳情", "個人頁", "Admin"];

function App2() {
  const [page, setPage] = useState(3);   // 預設打開合併後的探索頁
  const [device, setDevice] = useState("desktop");
  const [variant, setVariant] = useState(0);
  const [anno, setAnno] = useState(true);

  useEffect(() => { document.body.classList.toggle("no-anno", !anno); }, [anno]);
  useEffect(() => { setVariant(0); }, [page]);

  const P = V2_PAGES[page];
  const multi = P.variants.length > 1;

  return <div id="app">
    <div className="app-head">
      <div className="brand">新北美食地圖 <small>線稿 v2 · 已選定方向（桌機）· 對照 frontend-plan §3</small></div>
      <div className="head-ctrl">
        <div className="seg">
          <button className={device === "desktop" ? "on" : ""} onClick={() => setDevice("desktop")}>🖥 桌機</button>
          <button className={device === "mobile" ? "on" : ""} onClick={() => setDevice("mobile")}>📱 手機</button>
        </div>
        <label className="toggle"><input type="checkbox" checked={anno} onChange={e => setAnno(e.target.checked)} /> API 註記</label>
      </div>
    </div>

    <div className="legend">
      <span><span className="anno">GET /api/…</span> 端點</span>
      <span><span className="anno m">POST /api/…</span> 寫入/動作</span>
      <span><span className="bind">field</span> render 欄位</span>
      <span className="muted">· 多個狀態的頁面用上方「狀態」分頁切換</span>
    </div>

    <div className="pagerail">
      {V2_PAGES.map((p, i) =>
        <div key={i} className={"ptab" + (i === page ? " on" : "")} onClick={() => setPage(i)}>
          <span className="n">{String(i + 1).padStart(2, "0")}</span>{V2_LABELS[i]}
        </div>)}
    </div>

    <div className="pintro">
      <div style={{ flex: 1, minWidth: 280 }}>
        <div className="row center gap12 wrap"><h2>{P.title}</h2><span className="path mono">{P.path}</span></div>
        <p>{P.desc}</p>
      </div>
    </div>

    {device === "desktop" && multi &&
      <div className="vtabs">
        {P.variants.map((v, i) =>
          <div key={i} className={"vtab" + (i === variant ? " on" : "")} onClick={() => setVariant(i)}>
            <b>{v.tag}</b><span>{v.cap}</span>
          </div>)}
      </div>}

    <Stage device={device} url={P.path} variants={P.variants} active={multi ? variant : 0} />
  </div>;
}

ReactDOM.createRoot(document.getElementById("root")).render(<App2 />);
