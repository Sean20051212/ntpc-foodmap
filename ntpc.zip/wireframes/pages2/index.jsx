/* v2 · 03 首頁（選定：方案C 搜尋優先 hero） */
function V2Rec() {
  return <div className="wcard">
    <div style={{ position: "relative" }}>
      <Ph label="main_photo_url" h={120} r={0} style={{ borderWidth: 0 }} />
      <div style={{ position: "absolute", top: 8, right: 8 }}><Heart /></div>
    </div>
    <div style={{ padding: 12 }}>
      <b className="hand" style={{ fontSize: 16 }}>蘇義興餐廳</b>
      <div className="row center gap6" style={{ margin: "3px 0" }}><Stars n={4} size={13} /><span className="lbl" style={{ fontSize: 12 }}>4.2 (15)</span></div>
      <Bars lines={2} w={["100%", "62%"]} />
      <ARow style={{ marginTop: 6 }}><Bind>rating_avg</Bind><Bind>rating_count</Bind><Bind>description 前60字</Bind></ARow>
    </div>
  </div>;
}

window.V2_index = {
  path: "/pages/index.php",
  title: "首頁",
  desc: "方案C 搜尋優先：跑馬燈當 hero 背景、大搜尋列壓在上面，下方三家推薦。開頁 GET /api/auth/me，未登入跳 login。",
  variants: [
    {
      tag: "選定", cap: "hero 搜尋 + 三家推薦",
      render: () => <div>
        <div className="ph plain" data-l="carousel 主視覺（8 秒自換）" style={{ height: 300, borderRadius: 0, position: "relative", flexDirection: "column", justifyContent: "center", gap: 16, padding: 24 }}>
          <b className="hand" style={{ fontSize: 32, textAlign: "center", position: "relative", zIndex: 1 }}>探索新北的味道</b>
          <div className="sk row center" style={{ background: "#fff", padding: 8, gap: 6, maxWidth: 560, width: "100%", position: "relative", zIndex: 1, margin: "0 auto" }}>
            <div className="seg"><button className="on">keyword</button><button>地址</button></div>
            <div className="sk-flat grow" style={{ padding: "8px 12px" }}><span className="muted hand">搜尋餐廳 / 輸入地址</span></div>
            <Btn pri>搜尋</Btn>
          </div>
          <div className="row" style={{ position: "absolute", bottom: 12, left: 0, right: 0, justifyContent: "center", gap: 6, zIndex: 1 }}>
            {[0, 1, 2, 3].map(i => <span key={i} style={{ width: 8, height: 8, borderRadius: 50, border: "1.5px solid var(--ink)", background: i === 0 ? "var(--accent)" : "#fff" }} />)}
          </div>
        </div>
        <ARow style={{ margin: "10px 16px 0" }}>
          <A>GET /api/auth/me（未登入跳 login）</A><A>GET /api/restaurants/carousel?limit=10</A><A m>setInterval 8000ms</A>
        </ARow>
        <div className="screenpad">
          <SecH>精選推薦</SecH>
          <div className="rec-row">
            <V2Rec /><V2Rec /><V2Rec />
          </div>
          <ARow style={{ marginTop: 8 }}><A>GET /api/restaurants/recommendations?limit=3</A><Bind>點卡 / 點圖 → detail.php?id=</Bind></ARow>
        </div>
      </div>
    }
  ]
};
