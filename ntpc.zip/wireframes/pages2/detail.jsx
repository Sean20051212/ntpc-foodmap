/* v2 · 06 詳情頁（選定：方案B 全幅 hero + 浮動縮圖） */
function OpenTable() {
  const days = ["一", "二", "三", "四", "五", "六", "日"];
  return <div className="sk-flat" style={{ padding: 10 }}>
    {days.map((d, i) => <div key={i} className="row between" style={{ padding: "3px 2px", borderBottom: i < 6 ? "1px dashed var(--paper-edge)" : "none" }}>
      <span className="hand" style={{ fontSize: 13 }}>週{d}</span>
      <span className="lbl mono" style={{ fontSize: 12 }}>{i === 4 ? "公休" : "11:00–21:00"}</span>
    </div>)}
  </div>;
}
function ReviewItem() {
  return <div className="sk-flat" style={{ padding: "10px 12px" }}>
    <div className="row between center">
      <div className="row center gap6"><div className="ph plain" data-l="" style={{ width: 26, height: 26, borderRadius: 50 }} /><b className="hand" style={{ fontSize: 14, textDecoration: "underline" }}>alice</b><span className="lbl" style={{ fontSize: 11 }}>· 7 則評論</span></div>
      <Stars n={5} size={12} />
    </div>
    <Bars lines={2} w={["100%", "66%"]} style={{ marginTop: 6 }} />
    <span className="lbl mono" style={{ fontSize: 10 }}>2025-11-02</span>
  </div>;
}

window.V2_detail = {
  path: "/pages/detail.php?id=",
  title: "詳情頁",
  desc: "方案B 沉浸式：全幅 hero 主圖 + 縮圖浮在右下、左右箭頭切換（照片 1~6 動態，只一張不顯示箭頭/縮圖）。徽章直接讀 is_open_now；評論 upsert（已有預填變「更新」）。",
  variants: [
    {
      tag: "選定", cap: "全幅 hero 大圖 + 右下浮動縮圖",
      render: () => <div>
        <div style={{ position: "relative" }}>
          <Ph label="全幅主圖 photos[0]" h={340} r={0} />
          <div className="row gap6" style={{ position: "absolute", bottom: 12, right: 12 }}>
            {Array.from({ length: 4 }).map((_, i) => <Ph key={i} label="" plain h={44} w={44} r={6} style={{ borderColor: "#fff", borderWidth: i === 0 ? 3 : 1.5 }} />)}
            <span className="badge" style={{ alignSelf: "center" }}>+2</span>
          </div>
          <div className="btn" style={{ position: "absolute", top: "50%", left: 14, transform: "translateY(-50%)", background: "#fff" }}>‹</div>
          <div className="btn" style={{ position: "absolute", top: "50%", right: 14, transform: "translateY(-50%)", background: "#fff" }}>›</div>
          <span className="badge" style={{ position: "absolute", top: 12, left: 12 }}>1 / 6</span>
        </div>
        <ARow style={{ margin: "8px 16px 0" }}><A m>GET /api/restaurants/detail?id=</A><Bind>photos[] 動態 1~6</Bind><Note>只 1 張 → 不顯示箭頭/縮圖</Note></ARow>

        <div className="screenpad">
          {/* info */}
          <div className="row between center">
            <b className="hand" style={{ fontSize: 26 }}>蘇義興餐廳</b>
            <div className="row center gap8"><Badge kind="open">營業中</Badge><Heart on /></div>
          </div>
          <div className="row center gap8" style={{ margin: "6px 0" }}>
            <Stars n={4} /><b className="hand">4.2</b><span className="lbl">(15 則)</span><span className="lbl">· $$ · 板橋區</span>
          </div>
          <ARow><Bind>rating_avg</Bind><Bind>rating_count</Bind><Bind>is_open_now</Bind><Bind>is_favorited</Bind><Bind>price_level</Bind></ARow>
          <div className="row wrap gap6" style={{ margin: "10px 0" }}><Chip>小吃／熱炒</Chip><Chip>台菜</Chip><Chip>📞 02-1234-5678</Chip></div>
          <Bars lines={2} w={["100%", "88%"]} />

          <div className="row gap16" style={{ marginTop: 14 }}>
            <div className="grow">
              <SecH>營業資訊 opentime_regular</SecH><OpenTable />
              <div style={{ marginTop: 8 }}><span className="lbl">特殊營業 opentime_special</span>
                <div className="row wrap gap6" style={{ marginTop: 6 }}><Chip>週五公休</Chip><Chip>農曆春節休</Chip></div></div>
            </div>
            <div className="grow">
              <SecH>寫評論</SecH>
              <div className="sk-flat" style={{ padding: 12 }}>
                <div className="row center gap6" style={{ marginBottom: 8 }}><span className="lbl">評分</span><Stars n={0} size={20} /></div>
                <div className="sk-flat" style={{ padding: 10, minHeight: 56 }}><span className="muted hand">分享你的用餐心得…（≤1000 字）</span></div>
                <div className="row between center" style={{ marginTop: 8 }}>
                  <span className="lbl" style={{ fontSize: 11 }}>已有評論 → 預填、按鈕變「更新」</span><Btn pri sm>送出評論</Btn>
                </div>
                <ARow style={{ marginTop: 8 }}><A m>POST /api/reviews/upsert</A><Bind>未登入→請先登入</Bind><Bind>user_review 預填</Bind></ARow>
              </div>
            </div>
          </div>

          <SecH>評論列表</SecH>
          <div className="col gap8"><ReviewItem /><ReviewItem /></div>
          <ARow style={{ marginTop: 8 }}>
            <A>GET /api/reviews/by_restaurant?restaurant_id=&limit=20&offset=0</A>
            <Bind>username→profile.php?id=</Bind><Bind>reviewer_total_reviews</Bind>
          </ARow>
        </div>
      </div>
    }
  ]
};
