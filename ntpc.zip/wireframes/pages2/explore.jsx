/* v2 · 04+05 合併 探索頁（搜尋/列表 ＋ 地圖同頁）
   篩選可收合到左邊、餐廳卡小、版面留給地圖；輪盤＝右側可收合側板（方案B） */
function MiniFilter({ collapsed }) {
  if (collapsed) return <div className="exp-filter" style={{ flex: "0 0 46px", borderRight: "2px solid var(--ink)", background: "var(--paper2)", display: "flex", flexDirection: "column", alignItems: "center", gap: 12, padding: "12px 0" }}>
    <div className="btn sm" style={{ padding: 6 }}>≡</div>
    <div style={{ writingMode: "vertical-rl", fontFamily: "'Patrick Hand'", fontSize: 13, color: "var(--ink2)" }}>篩選</div>
    <span className="badge" style={{ writingMode: "vertical-rl", padding: "8px 1px" }}>23</span>
  </div>;
  return <div className="exp-filter" style={{ flex: "0 0 212px", borderRight: "2px solid var(--ink)", background: "var(--paper2)", padding: 14 }}>
    <div className="row between center" style={{ marginBottom: 10 }}><b className="hand" style={{ fontSize: 15 }}>篩選</b><span className="btn sm" style={{ padding: "2px 8px" }}>« 收合</span></div>
    <div className="filt-row">
      <div className="ft">多選區域 <span className="lbl" style={{ fontSize: 11 }}>板橋+2</span></div>
      <div className="sk-flat row between center" style={{ padding: "7px 10px" }}><span className="muted hand">選擇區域 ▾</span></div>
      <ARow><A>GET /api/dicts/districts</A></ARow>
    </div>
    <div className="filt-row">
      <div className="ft">多選分類</div>
      <div className="row wrap gap6"><Chip on>小吃</Chip><Chip>火鍋</Chip><Chip on>早午餐</Chip><Chip>+9</Chip></div>
      <ARow><A>GET /api/dicts/tags</A></ARow>
    </div>
    <div className="filt-row">
      <div className="ft">距離 <span className="lbl" style={{ fontSize: 11 }}>≤300m</span></div>
      <RangeBar pos={2} /><ARow><Bind>max_distance_m</Bind></ARow>
    </div>
    <div className="filt-row">
      <div className="ft">評分 <span className="lbl" style={{ fontSize: 11 }}>≥3★</span></div>
      <RangeBar scale={["不限", "1★", "2★", "3★", "4★"]} pos={3} /><ARow><Bind>min_rating</Bind></ARow>
    </div>
    <div className="sk-flat" style={{ background: "var(--accent-soft)", borderColor: "var(--accent)", padding: "7px 10px", textAlign: "center" }}><b className="hand">找到 <span style={{ color: "var(--accent)" }}>23</span> 家</b></div>
    <ARow style={{ marginTop: 6 }}><A m>變動 debounce300ms → /count</A></ARow>
  </div>;
}

function MiniCard({ active }) {
  return <div className="wcard row" style={{ alignItems: "stretch", borderColor: active ? "var(--accent)" : "var(--ink)" }}>
    <Ph label="圖" w={68} h="auto" r={0} style={{ borderWidth: "0 2px 0 0", flex: "0 0 68px", minHeight: 64 }} />
    <div style={{ padding: "7px 9px", flex: 1 }}>
      <div className="row between center"><b className="hand" style={{ fontSize: 14 }}>蘇義興餐廳</b><Heart on={active} /></div>
      <div className="row center gap6" style={{ margin: "1px 0" }}><Stars n={4} size={11} /><span className="lbl" style={{ fontSize: 10 }}>4.2</span></div>
      <div className="row center gap6"><Badge kind="open">營業中</Badge><span className="lbl" style={{ fontSize: 10 }}>320m · $$</span></div>
    </div>
  </div>;
}

function ExploreMap({ wheel }) {
  return <div className="grow exp-map" style={{ position: "relative", minHeight: 470 }}>
    <div className="ph plain" data-l="Google Maps（marker = main_photo_url，收藏永久愛心）" style={{ height: "100%", borderRadius: 0, borderWidth: 0, position: "absolute", inset: 0 }} />
    {[[18, 26], [42, 20], [30, 48], [60, 58], [24, 66], [52, 40]].map(([t, l], i) =>
      <div key={i} style={{ position: "absolute", top: t + "%", left: l + "%" }}>
        <div className="heart" style={{ background: i % 3 === 0 ? "var(--accent)" : "#fff", color: i % 3 === 0 ? "#fff" : "var(--accent)" }}>♥</div>
      </div>)}
    <div style={{ position: "absolute", top: 12, left: "50%", transform: "translateX(-50%)" }}><Btn pri sm>↻ 重新搜尋此區域</Btn></div>
    {/* infoWindow */}
    <div className="sk" style={{ position: "absolute", top: "34%", left: "30%", background: "#fff", padding: 8, width: 190, boxShadow: "3px 4px 0 rgba(51,48,42,.15)" }}>
      <Ph label="主圖 is_main" h={60} r={6} style={{ borderWidth: 0 }} />
      <b className="hand" style={{ fontSize: 14, display: "block", marginTop: 4 }}>蘇義興餐廳</b>
      <div className="row center gap6"><Stars n={4} size={11} /><span className="lbl" style={{ fontSize: 10 }}>4.2</span></div>
      <Bars lines={1} w={["85%"]} />
      <div className="row between center" style={{ marginTop: 6 }}><Heart on /><Btn sm>詳情</Btn></div>
    </div>
    {/* wheel side panel (方案B) */}
    {wheel && <div className="sk" style={{ position: "absolute", top: 0, right: 0, bottom: 0, width: 270, borderRadius: 0, borderWidth: "0 0 0 2px", background: "#fff", padding: 16, boxShadow: "-4px 0 0 rgba(51,48,42,.08)" }}>
      <div className="row between center" style={{ marginBottom: 10 }}><b className="hand" style={{ fontSize: 17 }}>🎯 吃什麼輪盤</b><span className="btn sm">✕</span></div>
      <div className="ph plain" data-l="🎡 轉盤" style={{ width: 150, height: 150, borderRadius: 200, margin: "0 auto 12px" }} />
      <div className="sk-flat row" style={{ padding: 7, marginBottom: 10 }}>
        <Ph label="" plain w={56} h={52} r={6} style={{ borderWidth: 0 }} />
        <div style={{ padding: "2px 9px" }}><b className="hand" style={{ fontSize: 14 }}>抽中：蘇義興</b><div className="row center gap6"><Stars n={4} size={11} /><span className="lbl" style={{ fontSize: 10 }}>320m</span></div></div>
      </div>
      <div className="row gap8"><Btn pri style={{ flex: 1, justifyContent: "center" }}>再抽</Btn><Btn style={{ flex: 1, justifyContent: "center" }}>詳情</Btn></div>
      <ARow style={{ marginTop: 10 }}><A>GET /wheel_pool?同篩選</A><A m>POST /wheel_draw</A></ARow>
      <ARow style={{ marginTop: 4 }}><Bind>抽過排除＝後端 session</Bind><A m>抽完 → POST /wheel_reset</A></ARow>
    </div>}
  </div>;
}

function ExploreShell({ collapsed, wheel }) {
  const [mtab, setMtab] = useState("list");
  return <div className={"explore mtab-" + mtab}>
    <div className="row center gap8" style={{ padding: "10px 14px", borderBottom: "2px solid var(--ink)", background: "var(--paper2)" }}>
      <div className="sk-flat grow row center" style={{ padding: "7px 12px" }}><span className="muted hand">🔍 搜尋餐廳 / 地址</span></div>
      <Btn sm>排序 ▾</Btn>
      <Btn sm pri={wheel}>🎯 輪盤</Btn>
      <span className="show-m"><Btn sm>⚙</Btn></span>
    </div>
    <div className="exp-mtoggle" style={{ padding: "8px 14px", borderBottom: "2px solid var(--ink)", justifyContent: "center" }}>
      <div className="seg" style={{ width: "100%", maxWidth: 300 }}>
        <button className={mtab === "list" ? "on" : ""} style={{ flex: 1 }} onClick={() => setMtab("list")}>☰ 清單</button>
        <button className={mtab === "map" ? "on" : ""} style={{ flex: 1 }} onClick={() => setMtab("map")}>🗺 地圖</button>
      </div>
    </div>
    <div className="row" style={{ alignItems: "stretch" }}>
      <MiniFilter collapsed={collapsed} />
      <div className="exp-list" style={{ flex: "0 0 280px", borderRight: "2px solid var(--ink)", padding: 10, maxHeight: 470, overflow: "auto" }}>
        <div className="row between center" style={{ marginBottom: 8 }}><span className="lbl">23 家 · 板橋+鄰接</span><span className="lbl" style={{ fontSize: 11 }}>rating_desc</span></div>
        <div className="col gap8">
          <MiniCard active /><MiniCard /><MiniCard /><MiniCard /><MiniCard />
        </div>
        <ARow style={{ marginTop: 8 }}><A m>GET /api/restaurants/list?bbox=&district[]=&tag[]=</A></ARow>
        <Note>hover 卡片 ↔ map marker 連動；卡與 marker 同一份 list 結果</Note>
      </div>
      <ExploreMap wheel={wheel} />
    </div>
  </div>;
}

window.V2_explore = {
  path: "/pages/search.php ＝ map.php（合併）",
  title: "探索（搜尋＋地圖）",
  desc: "04 與 05 合併為同一頁：左篩選可收合、中間小卡清單、右側大地圖同時呈現。手機版用「清單／地圖」分頁切換（窄螢幕不並排）。開頁 POST /api/geo/locate 置中；in_ntpc=false → nearby_ntpc。idle 後不自動 reload，給「重新搜尋此區域」。輪盤＝右側可收合側板（方案B）。",
  variants: [
    { tag: "狀態 1", cap: "篩選展開 · 清單＋大地圖（infoWindow 開）", render: () => <ExploreShell collapsed={false} wheel={false} /> },
    { tag: "狀態 2", cap: "篩選收合 · 版面更給地圖 · 輪盤側板開", render: () => <ExploreShell collapsed={true} wheel={true} /> }
  ]
};
