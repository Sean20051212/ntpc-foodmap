/* v2 · 08 Admin（選定：一種設計，三個分頁/狀態：餐廳列表 / 使用者 / 編輯表單） */
function ARow2({ cols, disabled }) {
  return <div className="row center" style={{ padding: "8px 10px", borderBottom: "1px dashed var(--paper-edge)", opacity: disabled ? .5 : 1, gap: 8 }}>{cols}</div>;
}
function AdminTabs({ active }) {
  return <div className="seg" style={{ marginBottom: 12 }}>
    <button className={active === 0 ? "on" : ""}>餐廳管理</button>
    <button className={active === 1 ? "on" : ""}>使用者管理</button>
  </div>;
}

window.V2_admin = {
  path: "/pages/admin.php",
  title: "Admin 後台",
  desc: "同一套後台的三個畫面：餐廳列表（CRUD 入口）、使用者管理（promote/demote/delete，user_id=1 三鈕 disable）、編輯餐廳表單（含照片管理）。開頁 GET /api/auth/me 確認 is_admin。",
  variants: [
    {
      tag: "餐廳管理", cap: "資料表 + 新增/編輯/刪",
      render: () => <div className="screenpad">
        <div className="row between center wrap gap8" style={{ marginBottom: 12 }}><AdminTabs active={0} /><Btn pri sm>+ 新增餐廳</Btn></div>
        <div className="sk" style={{ overflow: "hidden" }}>
          <div className="row center" style={{ padding: "8px 10px", background: "var(--paper2)", borderBottom: "2px solid var(--ink)", fontSize: 12, gap: 8 }}>
            <b className="hand grow">餐廳名稱</b><b className="hand" style={{ width: 70 }}>區</b><b className="hand" style={{ width: 50 }}>評分</b><b className="hand" style={{ width: 100, textAlign: "right" }}>操作</b>
          </div>
          {Array.from({ length: 6 }).map((_, i) => <ARow2 key={i} cols={<>
            <span className="hand grow" style={{ fontSize: 14 }}>蘇義興餐廳</span>
            <span className="lbl" style={{ width: 70 }}>板橋</span>
            <span className="lbl" style={{ width: 50 }}>4.2</span>
            <div style={{ width: 100, textAlign: "right" }} className="row gap6"><Btn sm>編輯</Btn><Btn sm>刪</Btn></div>
          </>} />)}
        </div>
        <ARow style={{ marginTop: 8 }}><A>GET /api/restaurants/list?limit=50&offset=</A><A m>POST /api/admin/restaurant/delete</A><Note>編輯 → 載 detail 預填表單</Note></ARow>
      </div>
    },
    {
      tag: "使用者管理", cap: "super admin（user_id=1）三鈕 disable",
      render: () => <div className="screenpad">
        <AdminTabs active={1} />
        <div className="sk-flat row center" style={{ padding: "6px 10px", marginBottom: 10, maxWidth: 320 }}><span className="muted hand grow">🔍 搜尋帳號</span></div>
        <div className="sk" style={{ overflow: "hidden" }}>
          <div className="row center" style={{ padding: "8px 10px", background: "var(--paper2)", borderBottom: "2px solid var(--ink)", fontSize: 12, gap: 8 }}>
            <b className="hand" style={{ width: 36 }}>id</b><b className="hand grow">username</b><b className="hand" style={{ width: 60 }}>評論</b><b className="hand" style={{ width: 60 }}>收藏</b><b className="hand" style={{ width: 150, textAlign: "right" }}>操作</b>
          </div>
          <ARow2 disabled cols={<>
            <span className="mono" style={{ width: 36 }}>1</span>
            <span className="hand grow" style={{ fontSize: 14 }}>admin <span className="badge" style={{ fontSize: 10 }}>super</span></span>
            <span className="lbl" style={{ width: 60 }}>—</span><span className="lbl" style={{ width: 60 }}>—</span>
            <div style={{ width: 150, textAlign: "right" }} className="row gap6"><Btn sm>promote</Btn><Btn sm>demote</Btn><Btn sm>del</Btn></div>
          </>} />
          {[2, 3, 4].map(id => <ARow2 key={id} cols={<>
            <span className="mono" style={{ width: 36 }}>{id}</span>
            <span className="hand grow" style={{ fontSize: 14 }}>{["alice", "bob", "carol"][id - 2]} {id === 3 && <span className="badge">admin</span>}</span>
            <span className="lbl" style={{ width: 60 }}>{id * 3}</span><span className="lbl" style={{ width: 60 }}>{id * 2}</span>
            <div style={{ width: 150, textAlign: "right" }} className="row gap6"><Btn sm>{id === 3 ? "demote" : "promote"}</Btn><Btn sm>del</Btn></div>
          </>} />)}
        </div>
        <ARow style={{ marginTop: 8 }}>
          <A>GET /api/admin/users/list</A><A m>POST promote / demote / delete</A>
          <Bind>user_id=1 → 三鈕 disable（後端再擋）</Bind><Note>操作前 confirm</Note>
        </ARow>
      </div>
    },
    {
      tag: "編輯餐廳", cap: "新增/編輯表單 + 照片管理",
      render: () => <div className="screenpad">
        <div className="row between center" style={{ marginBottom: 10 }}><b className="hand" style={{ fontSize: 18 }}>編輯餐廳 #1</b><Btn sm>← 返回列表</Btn></div>
        <div className="row gap16">
          <div className="grow col gap10">
            {["餐廳名稱", "描述", "地址"].map(l => <div key={l}><span className="lbl">{l}</span><div className="sk-flat" style={{ padding: "8px 10px", marginTop: 3 }}><span className="muted hand">…</span></div></div>)}
            <div className="row gap8">
              <div className="grow"><span className="lbl">區 zipcode ▾</span><div className="sk-flat" style={{ padding: "8px 10px", marginTop: 3 }}><span className="muted hand">板橋 220 ▾</span></div></div>
              <div className="grow"><span className="lbl">價位</span><div className="sk-flat" style={{ padding: "8px 10px", marginTop: 3 }}><span className="muted hand">$$ ▾</span></div></div>
            </div>
            <div><span className="lbl">分類 tags（multi）</span><div className="row wrap gap6" style={{ marginTop: 4 }}><Chip on>小吃</Chip><Chip on>熱炒</Chip><Chip>+ 加</Chip></div></div>
            <ARow><A>dicts/districts</A><A>dicts/tags</A></ARow>
          </div>
          <div style={{ flex: "0 0 230px" }}>
            <span className="lbl">照片管理</span>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6, marginTop: 6 }}>
              {Array.from({ length: 4 }).map((_, i) => <div key={i} style={{ position: "relative" }}>
                <Ph label="" plain h={58} r={6} style={{ borderColor: i === 0 ? "var(--accent)" : "var(--ink)" }} />
                {i === 0 && <span className="badge" style={{ position: "absolute", top: 3, left: 3, fontSize: 9 }}>main</span>}
              </div>)}
              <div className="sk-flat" style={{ height: 58, display: "flex", alignItems: "center", justifyContent: "center" }}><span className="hand muted">+ url</span></div>
            </div>
            <ARow style={{ marginTop: 6 }}><A m>photo/upsert · /delete</A></ARow>
          </div>
        </div>
        <div className="row gap8" style={{ marginTop: 14 }}><Btn pri>儲存</Btn><Btn>取消</Btn></div>
        <ARow style={{ marginTop: 8 }}><A m>POST /api/admin/restaurant/upsert（transaction）</A></ARow>
      </div>
    }
  ]
};
