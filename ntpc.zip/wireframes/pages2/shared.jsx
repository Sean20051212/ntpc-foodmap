/* v2 · 01 共用元件（選定：方案A 整合列，改頭像選單） */
function Avatar({ ch = "陳", size = 36 }) {
  return <div style={{ width: size, height: size, borderRadius: "50%", border: "2px solid var(--ink)", background: "var(--accent-soft)", color: "var(--accent)", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Patrick Hand'", fontSize: size * 0.5 }}>{ch}</div>;
}

window.V2_shared = {
  path: "共用 navbar + 搜尋 bar",
  title: "共用元件",
  desc: "方案A 整合列：navbar 與搜尋同一條。右側改為「名字首字」圓形頭像；點頭像才展開個人頁 / 登出選單。收藏入口移除（改放各頁 context：地圖 marker、卡片、詳情）。",
  variants: [
    {
      tag: "選定", cap: "整合列 · 頭像下拉選單（展開示意）",
      render: () => <div className="screenpad">
        <SecH>navbar + search 單列（手機自動拆兩排、頭像移右上）</SecH>
        <div className="sk-flat" style={{ padding: "10px 14px", position: "relative", zIndex: 5 }}>
          <div className="navbar">
            <div className="nb-brand row center gap8">
              <div className="ph plain" data-l="L" style={{ width: 36, height: 36, borderRadius: 8 }} />
              <b className="hand" style={{ fontSize: 18 }}>美食地圖</b>
            </div>
            <div className="nb-search row center gap6">
              <div className="seg" style={{ flex: "0 0 auto" }}><button className="on">keyword</button><button>地址</button></div>
              <div className="sk-flat grow row center" style={{ padding: "8px 12px", minWidth: 80 }}><span className="muted hand">搜尋餐廳 / 輸入地址…</span></div>
              <Btn>🔍</Btn>
            </div>
            <div className="nb-avatar">
              <Avatar />
            </div>
          </div>
          {/* dropdown */}
          <div className="sk-flat" style={{ position: "absolute", top: 56, right: 14, width: 170, padding: 6, boxShadow: "4px 5px 0 rgba(51,48,42,.12)", zIndex: 9 }}>
            <div className="row center gap8" style={{ padding: "7px 10px", borderBottom: "1px dashed var(--paper-edge)" }}>
              <Avatar size={26} /><b className="hand" style={{ fontSize: 14 }}>陳大明</b>
            </div>
            <div className="hand" style={{ padding: "8px 10px", fontSize: 14 }}>個人頁</div>
            <div className="hand" style={{ padding: "8px 10px", fontSize: 14, color: "var(--accent)" }}>登出</div>
          </div>
        </div>

        <ARow style={{ marginTop: 12 }}>
          <A>GET /api/auth/me → {"{user.username}"} 取首字</A>
          <A>keyword: debounce300ms → /search.php?keyword=</A>
          <A m>地址: POST /api/geo/geocode → /search.php?user_lat=&user_lng=</A>
        </ARow>
        <ARow style={{ marginTop: 5 }}>
          <Bind>頭像 = username[0]</Bind><Bind>選單：個人頁 / 登出</Bind><A m>登出 → POST /api/auth/logout</A>
        </ARow>

        <SecH>搜尋自動補全（點搜尋框展開）</SecH>
        <div className="sk-flat" style={{ padding: 8, maxWidth: 460 }}>
          <Bars lines={3} w={["60%", "48%", "70%"]} />
        </div>
        <ARow style={{ marginTop: 6 }}><Bind>localStorage.searchHistory（最近5筆，FIFO50）</Bind></ARow>

        <Note>收藏鈕不放 navbar：收藏狀態以愛心出現在地圖 marker、卡片、詳情頁；收藏清單可從個人頁進入</Note>
      </div>
    }
  ]
};
