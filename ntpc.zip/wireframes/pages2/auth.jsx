/* v2 · 02 登入/註冊（選定：方案A 置中單卡 + 方案C 卡內內容） */
window.V2_auth = {
  path: "/pages/login.php · register.php",
  title: "登入 / 註冊",
  desc: "方案A 置中單卡外殼 ＋ 方案C 的卡內內容（歡迎語、登入表單、錯誤提示、切換註冊）。強制登入；舊假登入邏輯砍掉。register 成功自動登入跳首頁。",
  variants: [
    {
      tag: "選定", cap: "置中單卡 · 歡迎式登入內容",
      render: () => <div className="screenpad" style={{ display: "flex", justifyContent: "center", padding: "40px 16px" }}>
        <div className="sk" style={{ width: 400, padding: 26 }}>
          <div className="col center" style={{ gap: 4, marginBottom: 16 }}>
            <div className="ph plain" data-l="LOGO" style={{ width: 52, height: 52, borderRadius: 12 }} />
            <b className="hand" style={{ fontSize: 22, marginTop: 6 }}>歡迎回來 👋</b>
            <span className="lbl">登入新北美食地圖，開始探索</span>
          </div>
          <div className="seg" style={{ width: "100%", marginBottom: 18 }}>
            <button className="on" style={{ flex: 1 }}>登入</button><button style={{ flex: 1 }}>註冊</button>
          </div>
          <span className="lbl">帳號 username</span>
          <div className="sk-flat" style={{ padding: "10px 12px", margin: "4px 0 12px" }}><span className="muted hand">3–50 字</span></div>
          <span className="lbl">密碼 password</span>
          <div className="sk-flat" style={{ padding: "10px 12px", margin: "4px 0 8px" }}><span className="muted hand">•••••••• （≥8 字）</span></div>
          <div className="row between center" style={{ marginBottom: 14 }}>
            <span className="lbl" style={{ fontSize: 12 }}>沒有帳號？<u>立即註冊</u></span>
            <span className="lbl" style={{ fontSize: 12, color: "var(--accent)" }}>帳號或密碼錯誤</span>
          </div>
          <Btn pri style={{ width: "100%", justifyContent: "center" }}>登入</Btn>
          <ARow style={{ marginTop: 14 }}>
            <A m>POST /api/auth/login</A><A m>POST /api/auth/register</A>
          </ARow>
          <ARow style={{ marginTop: 5 }}>
            <Bind>成功 → /pages/index.php</Bind><Bind>conflict → 帳號已存在</Bind><Bind>密碼 bcrypt 後端處理</Bind>
          </ARow>
        </div>
      </div>
    }
  ]
};
