/* v2 · 07 個人頁（選定：方案A 看自己 + 方案C 看別人）
   看自己：移除 ******** 密碼裝飾；我的評論 + 我的收藏 皆可用向下箭頭收合 */
function PReview() {
  return <div className="wcard row" style={{ alignItems: "stretch" }}>
    <Ph label="圖" w={96} h="auto" r={0} style={{ borderWidth: "0 2px 0 0", flex: "0 0 96px", minHeight: 70 }} />
    <div style={{ padding: "10px 12px", flex: 1 }}>
      <div className="row between center"><b className="hand" style={{ fontSize: 15 }}>蘇義興餐廳</b><Stars n={5} size={12} /></div>
      <Bars lines={2} w={["100%", "70%"]} style={{ marginTop: 6 }} />
      <span className="lbl mono" style={{ fontSize: 10 }}>2025-11-02</span>
      <ARow style={{ marginTop: 4 }}><Bind>點評論 → detail.php?id=#review-uid</Bind></ARow>
    </div>
  </div>;
}

/* 收藏卡：與評論卡同型，含詳情跳轉 + 取消收藏 */
function FavCard() {
  return <div className="wcard row" style={{ alignItems: "stretch" }}>
    <Ph label="圖" w={96} h="auto" r={0} style={{ borderWidth: "0 2px 0 0", flex: "0 0 96px", minHeight: 70 }} />
    <div style={{ padding: "10px 12px", flex: 1 }}>
      <div className="row between center"><b className="hand" style={{ fontSize: 15 }}>蘇義興餐廳</b><Badge kind="open">營業中</Badge></div>
      <div className="row center gap6" style={{ margin: "3px 0" }}><Stars n={4} size={12} /><span className="lbl" style={{ fontSize: 11 }}>4.2 · 320m · $$</span></div>
      <div className="row wrap gap6"><Chip>小吃</Chip><Chip>熱炒</Chip></div>
      <div className="row between center" style={{ marginTop: 8 }}>
        <span className="anno-row"><Bind>點卡 → detail.php?id=</Bind></span>
        <span className="btn sm"><Heart on /> 取消收藏</span>
      </div>
      <ARow style={{ marginTop: 6 }}><A m>取消收藏 → POST /api/favorites/toggle</A></ARow>
    </div>
  </div>;
}

/* 可收合區塊：標題列點擊 → 收合，箭頭旋轉 */
function Collapse({ title, count, start = true, children }) {
  const [open, setOpen] = useState(start);
  return <div>
    <div className="sech-tog" onClick={() => setOpen(!open)}>
      {title}{count != null && <span className="lbl" style={{ fontSize: 13 }}>（{count}）</span>}
      <span className={"arw" + (open ? "" : " closed")}>▾</span>
    </div>
    {open && children}
  </div>;
}

function ProfileSelf() {
  return <div className="screenpad">
    <div className="sk" style={{ padding: 16, display: "grid", gridTemplateColumns: "72px 1fr", gap: 16, alignItems: "center", width: "100%" }}>
      <div style={{ width: 72, height: 72, borderRadius: "50%", border: "2px solid var(--ink)", background: "var(--accent-soft)", color: "var(--accent)", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Patrick Hand'", fontSize: 34 }}>陳</div>
      <div style={{ minWidth: 0 }}>
        <b className="hand" style={{ fontSize: 22 }}>陳大明</b>
        <div className="row center gap12 wrap" style={{ marginTop: 4 }}><span className="lbl">12 則評論</span><span className="lbl">8 收藏</span><span className="lbl">加入 2024</span></div>
        <div className="row gap8" style={{ marginTop: 10 }}><Btn sm>修改密碼</Btn><Btn sm>登出</Btn></div>
      </div>
    </div>
    <ARow style={{ marginTop: 8 }}>
      <A>GET /api/users/profile?user_id=</A><A m>POST /api/auth/change_password</A><A m>POST /api/auth/logout</A>
    </ARow>
    <Note>修改密碼 modal：舊密碼 + 新密碼 ×2（不顯示任何真實密碼）</Note>

    <Collapse title="我的評論" count={12}>
      <div className="col gap10"><PReview /><PReview /><PReview /></div>
      <ARow style={{ marginTop: 8 }}><A>GET /api/reviews/by_user?user_id=</A></ARow>
    </Collapse>

    <Collapse title="我的收藏" count={8}>
      <div className="col gap10"><FavCard /><FavCard /></div>
      <ARow style={{ marginTop: 8 }}><A>GET /api/favorites/list</A></ARow>
    </Collapse>
  </div>;
}

window.V2_profile = {
  path: "/pages/profile.php?id=",
  title: "個人頁",
  desc: "方案A 版面。看自己：修改密碼 + 登出，我的評論 / 我的收藏 各自可用向下箭頭收合（收藏含詳情跳轉 + 取消收藏）。看別人：只 username + 評論。已移除無意義的 ******** 密碼欄。",
  variants: [
    {
      tag: "看自己", cap: "我的評論 + 我的收藏（可收合）· 無密碼欄",
      render: () => <ProfileSelf />
    },
    {
      tag: "看別人", cap: "精簡（無修改 / 登出 / 收藏）",
      render: () => <div className="screenpad">
        <div className="sk row center gap16" style={{ padding: 16 }}>
          <div style={{ width: 64, height: 64, borderRadius: "50%", border: "2px solid var(--ink)", background: "var(--accent-soft)", color: "var(--accent)", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Patrick Hand'", fontSize: 30, flex: "0 0 64px" }}>A</div>
          <div><b className="hand" style={{ fontSize: 20 }}>alice</b><div className="lbl">7 則評論 · 美食探索家</div></div>
        </div>
        <Note>user_id ≠ currentUser → 不顯示修改密碼 / 登出 / 收藏</Note>
        <SecH>alice 的評論</SecH>
        <div className="col gap10"><PReview /><PReview /></div>
        <ARow style={{ marginTop: 8 }}>
          <A>GET /api/users/profile?user_id=</A><A>GET /api/reviews/by_user?user_id=</A>
        </ARow>
      </div>
    }
  ]
};
