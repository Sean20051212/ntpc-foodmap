/* ============================================================
   Wireframe primitives — shared building blocks
   每個檔結尾 Object.assign(window, …) 讓其他 babel script 取用
   ============================================================ */
const { useState, useEffect, useRef } = React;

/* image placeholder */
function Ph({ label = "IMG", h = 120, w, r, plain, style }) {
  return <div className={"ph" + (plain ? " plain" : "")} data-l={label}
    style={{ height: h, width: w || "100%", borderRadius: r, ...style }} />;
}

/* lorem bars */
function Bars({ lines = 3, w = ["100%", "92%", "70%"], dk, style }) {
  return <div className="bars" style={style}>
    {Array.from({ length: lines }).map((_, i) =>
      <span key={i} className={"bar" + (dk ? " dk" : "")} style={{ width: w[i % w.length] }} />)}
  </div>;
}

/* one fake text line of given width */
const Bar = ({ w = "100%", dk }) => <span className={"bar" + (dk ? " dk" : "")} style={{ width: w }} />;

/* star rating row (visual only — value comes from rating_avg) */
function Stars({ n = 4, total = 5, size = 15 }) {
  return <span className="star" style={{ fontSize: size }}>
    {Array.from({ length: total }).map((_, i) =>
      <span key={i} className={i < n ? "" : "e"}>★</span>)}
  </span>;
}

const Btn = ({ children, pri, sm, style }) =>
  <span className={"btn" + (pri ? " pri" : "") + (sm ? " sm" : "")} style={style}>{children}</span>;

const Chip = ({ children, on }) => <span className={"chip" + (on ? " on" : "")}>{children}</span>;

/* API endpoint annotation */
const A = ({ children, m }) => <span className={"anno" + (m ? " m" : "")}>{children}</span>;
/* field data-bind annotation */
const Bind = ({ children }) => <span className="bind">{children}</span>;
const ARow = ({ children }) => <div className="anno-row">{children}</div>;

const Heart = ({ on }) => <span className={"heart" + (on ? " on" : "")}>♥</span>;

const Badge = ({ children, kind }) => <span className={"badge" + (kind ? " " + kind : "")}>{children}</span>;

const SecH = ({ children }) => <div className="sech">{children}</div>;

const Note = ({ children }) => <div className="note">✎ {children}</div>;

/* distance / range slider mock (不限 / 100 / 300 / 500 / 800 / 1000) */
function RangeBar({ scale = ["不限", "100", "300", "500", "800", "1k"], pos = 2 }) {
  const left = (pos / (scale.length - 1)) * 100;
  return <div>
    <div className="slider">
      <div className="track">
        <div className="ticks">{scale.map((_, i) => <i key={i} />)}</div>
        <div className="knob" style={{ left: left + "%" }} />
      </div>
    </div>
    <div className="scale">{scale.map((s, i) => <span key={i}>{s}</span>)}</div>
  </div>;
}

/* ---------- device frames ---------- */
function Browser({ url, children }) {
  return <div className="browser">
    <div className="chrome">
      <div className="dot" /><div className="dot" /><div className="dot" />
      <div className="url mono">{url}</div>
    </div>
    <div className="wbody">{children}</div>
  </div>;
}

function Phone({ cap, url, children }) {
  return <div className="phone-wrap">
    <div className="phone">
      <div className="screen">
        <div className="notch" />
        <div className="statusbar"><span>9:41</span><span>{url}</span><span>▮▮ 100%</span></div>
        <div className="pbody">{children}</div>
      </div>
    </div>
    {cap && <div className="phone-cap">{cap}</div>}
  </div>;
}

/* Render one variation inside the right device frame.
   `render` is (mode) => JSX where mode is "d" | "m". */
function Stage({ device, url, variants, active }) {
  if (device === "desktop") {
    const v = variants[active];
    return <div className="stage desktop">
      <div className="vcap"><b>{v.tag}</b><span>{v.cap}</span></div>
      <Browser url={url}>{v.render("d")}</Browser>
    </div>;
  }
  return <div className="stage">
    {variants.map((v, i) =>
      <Phone key={i} url={url} cap={v.tag + " · " + v.cap}>{v.render("m")}</Phone>)}
  </div>;
}

Object.assign(window, { Ph, Bars, Bar, Stars, Btn, Chip, A, Bind, ARow, Heart, Badge, SecH, Note, RangeBar, Browser, Phone, Stage, useState, useEffect, useRef });
