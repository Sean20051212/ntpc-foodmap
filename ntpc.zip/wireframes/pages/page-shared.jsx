/* 3.9 + 3.10 共用 component：搜尋 bar + 登入狀態 navbar */
window.PAGE_shared = {
  path: "components",
  title: "共用 component",
  desc: "搜尋 bar（keyword / 地址兩模式）與登入狀態 navbar，所有頁共用。先決定它們的形態，其他頁直接套。",
  variants: [
    {
      tag: "A", cap: "頂部整合列：navbar + 搜尋同一條",
      render: () => <div className="screenpad">
        <SecH>navbar + search 合併單列</SecH>
        <div className="sk-flat" style={{ border: "2px solid var(--ink)", padding: "10px 12px" }}>
          <div className="row center between wrap gap12">
            <div className="row center gap8">
              <div className="ph plain" data-l="LOGO" style={{ width: 38, height: 38, borderRadius: 8 }} />
              <b className="hand" style={{ fontSize: 18 }}>美食地圖</b>
            </div>
            <div className="row center grow gap6" style={{ minWidth: 180 }}>
              <div className="seg" style={{ flex: "0 0 auto" }}>
                <button className="on">keyword</button><button>地址</button>
              </div>
              <div className="sk-flat grow row center" style={{ padding: "7px 12px", minWidth: 120 }}>
                <span className="muted hand">搜尋餐廳 / 輸入地址…</span>
              </div>
              <Btn>🔍</Btn>
            </div>
            <div className="row center gap8 hide-m">
              <span className="lbl">Hi, <b>user</b></span>
              <Chip>收藏</Chip><Chip>個人</Chip><Chip>登出</Chip>
            </div>
            <Btn sm style={{ display: "none" }}>☰</Btn>
          </div>
          <div className="show-m" style={{ marginTop: 8 }}><Btn sm>☰ 選單</Btn></div>
        </div>
        <ARow style={{ marginTop: 10 }}>
          <A>GET /api/auth/me → {"{user}"}</A>
          <A>keyword: debounce 300ms → /search.php?keyword=</A>
          <A m>地址: POST /api/geo/geocode → /search.php?user_lat=&user_lng=</A>
        </ARow>
        <div style={{ marginTop: 12 }}>
          <span className="lbl">自動補全（LocalStorage 最近 5 筆）</span>
          <div className="sk-flat" style={{ marginTop: 6, padding: 8 }}>
            <Bars lines={3} w={["60%", "48%", "70%"]} />
          </div>
          <ARow style={{ marginTop: 6 }}><Bind>localStorage.searchHistory (FIFO 50)</Bind></ARow>
        </div>
      </div>
    },
    {
      tag: "B", cap: "雙層：navbar 在上、巨大搜尋列在下",
      render: () => <div className="screenpad">
        <SecH>第一層 navbar（細）</SecH>
        <div className="sk-flat row center between" style={{ padding: "7px 12px" }}>
          <b className="hand" style={{ fontSize: 17 }}>🍜 美食地圖</b>
          <div className="row center gap6">
            <Chip>收藏</Chip><Chip on>Hi, user</Chip><Chip>登出</Chip>
          </div>
        </div>
        <SecH>第二層 hero 搜尋（大）</SecH>
        <div className="ph plain" data-l="背景：地圖底圖" style={{ height: 96, borderRadius: 10, display: "flex", flexDirection: "column", justifyContent: "center", padding: 14 }}>
          <div className="row center gap6" style={{ width: "100%" }}>
            <div className="seg"><button className="on">keyword</button><button>地址</button></div>
            <div className="sk grow row center" style={{ padding: "10px 14px", background: "#fff" }}>
              <span className="muted hand">想吃什麼？</span>
            </div>
            <Btn pri>搜尋</Btn>
          </div>
        </div>
        <ARow style={{ marginTop: 10 }}>
          <A>GET /api/auth/me</A><A>POST /api/geo/geocode</A>
          <Bind>localStorage.geocodeCache (TTL 24h)</Bind>
        </ARow>
        <Note>地址模式才有「搜尋」按鈕；keyword 模式打字即跳轉</Note>
      </div>
    },
    {
      tag: "C", cap: "navbar 純導覽 + 搜尋為可展開抽屜",
      render: () => <div className="screenpad">
        <SecH>navbar：只放品牌 + 帳號</SecH>
        <div className="sk-flat row center between" style={{ padding: "8px 12px" }}>
          <div className="row center gap8"><div className="ph plain" data-l="L" style={{ width: 30, height: 30, borderRadius: 6 }} /><b className="hand">美食地圖</b></div>
          <div className="row center gap6"><Btn sm>🔍 搜尋</Btn><div className="heart">♥</div><div className="ph plain" data-l="頭像" style={{ width: 30, height: 30, borderRadius: 50 }} /></div>
        </div>
        <SecH>點「搜尋」展開 overlay 抽屜</SecH>
        <div className="sk" style={{ padding: 14, background: "var(--paper2)" }}>
          <div className="row center gap6">
            <div className="seg"><button className="on">keyword</button><button>地址</button></div>
            <div className="sk grow" style={{ padding: "9px 12px", background: "#fff" }}><span className="muted hand">輸入…</span></div>
            <Btn pri>Go</Btn>
          </div>
          <div style={{ marginTop: 10 }}>
            <span className="lbl">最近搜尋</span>
            <div className="row wrap gap6" style={{ marginTop: 6 }}>
              <Chip>板橋 牛肉麵</Chip><Chip>永和 早餐</Chip><Chip>中和路 100 號</Chip>
            </div>
          </div>
        </div>
        <ARow style={{ marginTop: 10 }}>
          <A>GET /api/auth/me</A><Bind>未登入 → 顯示「登入 / 註冊」</Bind>
        </ARow>
      </div>
    }
  ]
};
