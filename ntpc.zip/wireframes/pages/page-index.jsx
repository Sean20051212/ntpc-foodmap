/* 3.3 index.php 首頁：開頁 auth/me → 搜尋 bar → 跑馬燈 → 三家推薦 */
function RecCard({ m, dense }) {
  return <div className="wcard" style={{ display: "flex", flexDirection: dense ? "row" : "column" }}>
    <Ph label="main_photo_url" h={dense ? 96 : 110} w={dense ? 110 : "100%"} r={0} style={{ borderWidth: 0, flex: dense ? "0 0 110px" : "none" }} />
    <div style={{ padding: dense ? "8px 12px" : 12, flex: 1 }}>
      <div className="row between center">
        <b className="hand" style={{ fontSize: 16 }}>蘇義興餐廳</b>
        <Heart />
      </div>
      <div className="row center gap6" style={{ margin: "3px 0" }}>
        <Stars n={4} size={13} /><span className="lbl" style={{ fontSize: 12 }}>4.2 (15)</span>
      </div>
      <Bars lines={dense ? 1 : 2} w={["100%", "62%"]} />
      <ARow style={{ marginTop: 6 }}>
        <Bind>rating_avg</Bind><Bind>rating_count</Bind><Bind>description 前60字</Bind>
      </ARow>
    </div>
  </div>;
}

window.PAGE_index = {
  path: "/pages/index.php",
  title: "首頁",
  desc: "開頁先 GET /api/auth/me，未登入跳 login。上方搜尋 bar、中間 8 秒跑馬燈、下方三家推薦。點圖 / 卡 → detail。",
  variants: [
    {
      tag: "A", cap: "經典縱向：大跑馬燈 + 三卡橫排",
      render: (m) => <div>
        <div className="sk-flat row center between" style={{ margin: 12, padding: "8px 12px" }}>
          <b className="hand">🍜 美食地圖</b>
          <div className="sk-flat grow row center" style={{ margin: "0 10px", padding: "6px 10px" }}><span className="muted hand">搜尋…</span></div>
          <Chip on>Hi,user</Chip>
        </div>
        <div className="screenpad" style={{ paddingTop: 0 }}>
          <div style={{ position: "relative" }}>
            <Ph label="跑馬燈大圖 (carousel)" h={m === "m" ? 150 : 220} />
            <div className="row" style={{ position: "absolute", bottom: 8, left: 0, right: 0, justifyContent: "center", gap: 6 }}>
              {[0, 1, 2, 3].map(i => <span key={i} style={{ width: 8, height: 8, borderRadius: 50, border: "1.5px solid var(--ink)", background: i === 0 ? "var(--accent)" : "transparent" }} />)}
            </div>
          </div>
          <ARow style={{ marginTop: 8 }}>
            <A>GET /api/restaurants/carousel?limit=10</A><A m>setInterval 8000ms</A><Bind>點圖 → detail.php?id=</Bind>
          </ARow>
          <SecH>為你推薦</SecH>
          <div className="row gap12" style={{ flexDirection: m === "m" ? "column" : "row" }}>
            <div className="grow"><RecCard m={m} /></div>
            <div className="grow"><RecCard m={m} /></div>
            <div className="grow"><RecCard m={m} /></div>
          </div>
          <ARow style={{ marginTop: 8 }}><A>GET /api/restaurants/recommendations?limit=3</A></ARow>
        </div>
      </div>
    },
    {
      tag: "B", cap: "並排：跑馬燈左、推薦清單右（桌機善用寬度）",
      render: (m) => <div className="screenpad">
        <div className="sk-flat row center between" style={{ padding: "8px 12px", marginBottom: 12 }}>
          <b className="hand">美食地圖</b>
          <div className="sk-flat grow row center" style={{ margin: "0 10px", padding: "6px 10px" }}><span className="muted hand">想吃什麼？</span></div>
          <Chip on>user</Chip>
        </div>
        <div className="row gap16" style={{ flexDirection: m === "m" ? "column" : "row" }}>
          <div style={{ flex: m === "m" ? "none" : "0 0 58%" }}>
            <Ph label="carousel 主視覺" h={m === "m" ? 150 : 260} />
            <ARow style={{ marginTop: 6 }}><A>GET /api/restaurants/carousel</A></ARow>
          </div>
          <div className="grow">
            <SecH>三家推薦</SecH>
            <div className="col gap8">
              <RecCard m={m} dense /><RecCard m={m} dense /><RecCard m={m} dense />
            </div>
            <ARow style={{ marginTop: 6 }}><A>GET /api/restaurants/recommendations?limit=3</A></ARow>
          </div>
        </div>
      </div>
    },
    {
      tag: "C", cap: "搜尋優先 hero：大搜尋列壓在跑馬燈上",
      render: (m) => <div>
        <div className="ph plain" data-l="carousel 當背景" style={{ height: m === "m" ? 220 : 300, borderRadius: 0, position: "relative", flexDirection: "column", justifyContent: "center", gap: 14, padding: 20 }}>
          <b className="hand" style={{ fontSize: m === "m" ? 22 : 30, textAlign: "center", position: "relative", zIndex: 1 }}>探索新北的味道</b>
          <div className="sk row center" style={{ background: "#fff", padding: 8, gap: 6, maxWidth: 520, width: "100%", position: "relative", zIndex: 1 }}>
            <div className="seg"><button className="on">keyword</button><button>地址</button></div>
            <div className="grow" style={{ padding: "6px 8px" }}><span className="muted hand">搜尋餐廳 / 地址</span></div>
            <Btn pri>搜尋</Btn>
          </div>
          <div className="anno-row" style={{ position: "relative", zIndex: 1, justifyContent: "center" }}>
            <A m>GET /api/auth/me（未登入跳 login）</A>
          </div>
        </div>
        <div className="screenpad">
          <SecH>精選推薦</SecH>
          <div className="row gap12" style={{ flexDirection: m === "m" ? "column" : "row" }}>
            <div className="grow"><RecCard m={m} /></div>
            <div className="grow"><RecCard m={m} /></div>
            <div className="grow"><RecCard m={m} /></div>
          </div>
          <ARow style={{ marginTop: 8 }}>
            <A>GET /api/restaurants/recommendations?limit=3</A><A>carousel 在 hero 8s 自換</A>
          </ARow>
        </div>
      </div>
    }
  ]
};
