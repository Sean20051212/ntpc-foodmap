/* 3.5 map.php 地圖頁。全螢幕地圖 + 輪盤浮層 + 收藏愛心 + 重新搜尋此區域 */
function WheelModal({ m, mode }) {
  // mode: "pool" 候選 / "spin" 抽中 / "exhausted" 抽完
  return <div className="sk" style={{ background: "#fff", padding: 18, width: m === "m" ? "100%" : 340 }}>
    <div className="row between center" style={{ marginBottom: 10 }}>
      <b className="hand" style={{ fontSize: 18 }}>🎯 吃什麼輪盤</b><span className="btn sm">✕</span>
    </div>
    {mode === "exhausted" ? <div style={{ textAlign: "center", padding: "10px 0" }}>
      <Ph label="空盤插圖" h={90} w={120} style={{ margin: "0 auto 10px" }} />
      <b className="hand">候選都抽完了！</b>
      <div style={{ marginTop: 10 }}><Btn pri>重設輪盤</Btn></div>
      <ARow style={{ marginTop: 10, justifyContent: "center" }}><A m>exhausted:true → POST /wheel_reset</A></ARow>
    </div> : <div>
      <div className="ph plain" data-l={mode === "spin" ? "🎡 轉盤動畫 (rAF)" : "🎡 轉盤待機"} style={{ height: m === "m" ? 150 : 180, borderRadius: 200, margin: "0 auto 12px", width: m === "m" ? 150 : 180 }} />
      {mode === "spin"
        ? <div className="sk-flat row" style={{ padding: 8, marginBottom: 10 }}>
            <Ph label="抽中店主圖" w={70} h={64} r={6} style={{ borderWidth: 0 }} />
            <div style={{ padding: "2px 10px" }}><b className="hand">蘇義興餐廳</b><div className="row center gap6"><Stars n={4} size={12} /><span className="lbl" style={{ fontSize: 11 }}>4.2</span></div><span className="lbl" style={{ fontSize: 11 }}>板橋 · 320m</span></div>
          </div>
        : <div className="sk-flat" style={{ padding: "8px 12px", textAlign: "center", marginBottom: 10 }}><b className="hand">符合篩選 <span style={{ color: "var(--accent)" }}>23</span> 家候選</b></div>}
      <div className="row gap8">
        <Btn pri style={{ flex: 1, justifyContent: "center" }}>{mode === "spin" ? "再抽一次" : "開始抽"}</Btn>
        {mode === "spin" && <Btn style={{ flex: 1, justifyContent: "center" }}>看詳情</Btn>}
      </div>
      <ARow style={{ marginTop: 10 }}>
        <A>GET /wheel_pool?同篩選</A><A m>POST /wheel_draw</A>
      </ARow>
      <ARow style={{ marginTop: 4 }}><Bind>抽過排除 = 後端 session（前端不記）</Bind></ARow>
    </div>}
  </div>;
}

function MapBase({ m, children, reSearch }) {
  return <div className="ph plain" data-l="Google Maps 全螢幕 (markers = main_photo_url)" style={{ height: m === "m" ? 560 : 440, borderRadius: 0, position: "relative", justifyContent: "stretch", alignItems: "stretch" }}>
    {/* fake markers */}
    {[[20, 30], [55, 22], [38, 55], [70, 60], [28, 70]].map(([t, l], i) =>
      <div key={i} style={{ position: "absolute", top: t + "%", left: l + "%" }}>
        <div className="heart" style={{ background: i % 2 ? "var(--accent)" : "#fff", color: i % 2 ? "#fff" : "var(--accent)", borderColor: "var(--ink)" }}>♥</div>
      </div>)}
    {reSearch && <div style={{ position: "absolute", top: 12, left: 0, right: 0, textAlign: "center" }}>
      <Btn pri sm>↻ 重新搜尋此區域</Btn>
    </div>}
    {children}
  </div>;
}

window.PAGE_map = {
  path: "/pages/map.php",
  title: "地圖頁",
  desc: "全螢幕 Google Maps；locate 置中、list?bbox 取 markers。idle 後不自動 reload，顯示「重新搜尋此區域」。點 marker → infoWindow（收藏鈕 toggle）。收藏永久愛心。輪盤浮層抽過不重抽（後端 session）。",
  variants: [
    {
      tag: "A", cap: "輪盤＝置中 modal（浮在地圖最上層）",
      render: (m) => <MapBase m={m} reSearch>
        {/* floating wheel button */}
        <div style={{ position: "absolute", right: 14, bottom: 14 }}><Btn pri>🎯 輪盤</Btn></div>
        {/* modal overlay */}
        <div style={{ position: "absolute", inset: 0, background: "rgba(51,48,42,.32)", display: "flex", alignItems: "center", justifyContent: "center", padding: 14 }}>
          <WheelModal m={m} mode="pool" />
        </div>
      </MapBase>
    },
    {
      tag: "B", cap: "輪盤＝右側可收合側板（抽中即停留比較）",
      render: (m) => <div className="row" style={{ minHeight: m === "m" ? "auto" : 440, flexDirection: m === "m" ? "column" : "row" }}>
        <div className="grow"><MapBase m={m} reSearch>
          {/* infoWindow sample */}
          <div className="sk" style={{ position: "absolute", top: "30%", left: "18%", background: "#fff", padding: 8, width: 180 }}>
            <Ph label="主圖" h={60} r={6} style={{ borderWidth: 0 }} />
            <b className="hand" style={{ fontSize: 14, display: "block", marginTop: 4 }}>蘇義興餐廳</b>
            <div className="row center gap6"><Stars n={4} size={11} /><span className="lbl" style={{ fontSize: 10 }}>4.2</span></div>
            <Bars lines={1} w={["80%"]} />
            <div className="row between center" style={{ marginTop: 6 }}><Heart on /><Btn sm>詳情</Btn></div>
          </div>
        </MapBase></div>
        <div style={{ flex: m === "m" ? "none" : "0 0 320px", borderLeft: m === "m" ? "none" : "2px solid var(--ink)", borderTop: m === "m" ? "2px solid var(--ink)" : "none", padding: 14, background: "var(--paper2)" }}>
          <WheelModal m={m} mode="spin" />
        </div>
      </div>
    },
    {
      tag: "C", cap: "輪盤＝底部抽屜 sheet（手機友善）+ infoWindow",
      render: (m) => <div style={{ position: "relative" }}>
        <MapBase m={m} reSearch />
        <div className="sk" style={{ position: "absolute", left: 0, right: 0, bottom: 0, background: "#fff", borderRadius: "18px 18px 0 0", padding: 16 }}>
          <div style={{ width: 44, height: 5, background: "var(--soft)", borderRadius: 5, margin: "0 auto 12px" }} />
          <div className="row center between" style={{ marginBottom: 10 }}>
            <b className="hand" style={{ fontSize: 17 }}>🎯 吃什麼輪盤</b>
            <span className="badge">候選 23 家</span>
          </div>
          <div className="row gap12 center">
            <div className="ph plain" data-l="🎡" style={{ width: 90, height: 90, borderRadius: 200, flex: "0 0 90px" }} />
            <div className="grow">
              <span className="lbl">依目前地圖篩選抽一家，抽過不再出現</span>
              <div className="row gap8" style={{ marginTop: 8 }}><Btn pri style={{ flex: 1, justifyContent: "center" }}>開始抽</Btn><Btn>重設</Btn></div>
            </div>
          </div>
          <ARow style={{ marginTop: 10 }}>
            <A>GET /wheel_pool</A><A m>POST /wheel_draw</A><A>POST /wheel_reset</A>
          </ARow>
        </div>
      </div>
    }
  ]
};
