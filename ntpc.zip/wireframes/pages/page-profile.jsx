/* 3.7 profile.php?id= 個人頁。自己 vs 別人 兩種視圖 */
function MyReview({ m }) {
  return <div className="wcard row" style={{ alignItems: "stretch" }}>
    <Ph label="main_photo_url" w={m === "m" ? 76 : 96} h="auto" r={0} style={{ borderWidth: 0, flex: "0 0 " + (m === "m" ? 76 : 96) + "px" }} />
    <div style={{ padding: "10px 12px", flex: 1 }}>
      <div className="row between center"><b className="hand" style={{ fontSize: 15 }}>蘇義興餐廳</b><Stars n={5} size={12} /></div>
      <Bars lines={2} w={["100%", "70%"]} style={{ marginTop: 6 }} />
      <span className="lbl mono" style={{ fontSize: 10 }}>2025-11-02</span>
      <ARow style={{ marginTop: 4 }}><Bind>點評論 → detail.php?id=#review-uid</Bind></ARow>
    </div>
  </div>;
}

window.PAGE_profile = {
  path: "/pages/profile.php?id=",
  title: "個人頁",
  desc: "GET /api/users/profile?user_id= + GET /api/reviews/by_user。看自己：修改密碼 + 登出 + 密碼欄永遠 ********（純裝飾）。看別人：只有 username + 評論列表。",
  variants: [
    {
      tag: "A", cap: "頂部個人卡 + 評論列表（看自己）",
      render: (m) => <div className="screenpad">
        <div className="sk row center gap16" style={{ padding: 16, flexDirection: m === "m" ? "column" : "row", textAlign: m === "m" ? "center" : "left" }}>
          <div className="ph plain" data-l="頭像" style={{ width: 72, height: 72, borderRadius: 50, flex: "0 0 72px" }} />
          <div className="grow">
            <b className="hand" style={{ fontSize: 22 }}>my_username</b>
            <div className="row center gap8" style={{ marginTop: 4, justifyContent: m === "m" ? "center" : "flex-start" }}>
              <span className="lbl">12 則評論</span><span className="lbl">· 加入 2024</span>
            </div>
            <div className="row gap8" style={{ marginTop: 10, justifyContent: m === "m" ? "center" : "flex-start" }}>
              <Btn sm>修改密碼</Btn><Btn sm>登出</Btn>
            </div>
          </div>
          <div className="sk-flat" style={{ padding: "8px 12px" }}><span className="lbl">密碼</span><div className="mono" style={{ fontSize: 16, letterSpacing: 2 }}>********</div></div>
        </div>
        <ARow style={{ marginTop: 8 }}>
          <A>GET /api/users/profile?user_id=</A><A m>POST /api/auth/change_password</A><A>POST /api/auth/logout</A>
          <Bind>******** 純裝飾，不取原文</Bind>
        </ARow>
        <SecH>我的評論</SecH>
        <div className="col gap10"><MyReview m={m} /><MyReview m={m} /><MyReview m={m} /></div>
        <ARow style={{ marginTop: 8 }}><A>GET /api/reviews/by_user?user_id=</A></ARow>
      </div>
    },
    {
      tag: "B", cap: "左欄個人資訊固定 + 右欄評論（桌機）",
      render: (m) => <div className="row" style={{ minHeight: 320 }}>
        <div style={{ flex: m === "m" ? "none" : "0 0 240px", borderRight: m === "m" ? "none" : "2px solid var(--ink)", borderBottom: m === "m" ? "2px solid var(--ink)" : "none", padding: 18, textAlign: "center", background: "var(--paper2)" }}>
          <div className="ph plain" data-l="頭像" style={{ width: 80, height: 80, borderRadius: 50, margin: "0 auto 10px" }} />
          <b className="hand" style={{ fontSize: 19 }}>my_username</b>
          <div className="lbl" style={{ margin: "4px 0 14px" }}>12 則評論</div>
          <Btn sm style={{ width: "100%", justifyContent: "center", marginBottom: 8 }}>修改密碼</Btn>
          <Btn sm style={{ width: "100%", justifyContent: "center" }}>登出</Btn>
          <div className="sk-flat" style={{ padding: "6px 10px", marginTop: 12 }}><span className="lbl" style={{ fontSize: 11 }}>密碼</span> <span className="mono">********</span></div>
          <ARow style={{ marginTop: 10, justifyContent: "center" }}><A m>change_password</A></ARow>
        </div>
        <div className="grow screenpad">
          <SecH>我的評論 (12)</SecH>
          <div className="col gap10"><MyReview m={m} /><MyReview m={m} /></div>
          <ARow style={{ marginTop: 8 }}><A>GET /api/reviews/by_user?user_id=</A></ARow>
        </div>
      </div>
    },
    {
      tag: "C", cap: "看別人：精簡（無修改 / 登出按鈕）",
      render: (m) => <div className="screenpad">
        <div className="sk row center gap14" style={{ padding: 16 }}>
          <div className="ph plain" data-l="頭像" style={{ width: 60, height: 60, borderRadius: 50, flex: "0 0 60px" }} />
          <div><b className="hand" style={{ fontSize: 20 }}>alice</b><div className="lbl">7 則評論 · 美食探索家</div></div>
        </div>
        <Note>user_id ≠ currentUser → 不顯示修改密碼 / 登出 / 密碼欄</Note>
        <SecH>alice 的評論</SecH>
        <div className="col gap10"><MyReview m={m} /><MyReview m={m} /></div>
        <ARow style={{ marginTop: 8 }}>
          <A>GET /api/users/profile?user_id=</A><A>GET /api/reviews/by_user?user_id=</A>
        </ARow>
      </div>
    }
  ]
};
