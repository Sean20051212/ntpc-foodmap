/* App shell：頁籤 + 裝置切換 + A/B/C 變體 + API 註記開關 */
const PAGES = [
  window.PAGE_shared, window.PAGE_auth, window.PAGE_index, window.PAGE_search,
  window.PAGE_map, window.PAGE_detail, window.PAGE_profile, window.PAGE_admin
];
const TAB_LABELS = ["共用元件", "登入/註冊", "首頁", "搜尋/列表", "地圖", "詳情", "個人頁", "Admin"];

function App() {
  const [page, setPage] = useState(2);      // 預設首頁
  const [device, setDevice] = useState("desktop");
  const [variant, setVariant] = useState(0);
  const [anno, setAnno] = useState(true);

  useEffect(() => {
    document.body.classList.toggle("no-anno", !anno);
  }, [anno]);
  useEffect(() => { setVariant(0); }, [page]);

  const P = PAGES[page];

  return <div id="app">
    <div className="app-head">
      <div className="brand">新北美食地圖 <small>低保真線稿 · wireframe v1 · 對照 frontend-plan §3</small></div>
      <div className="head-ctrl">
        <div className="seg">
          <button className={device === "desktop" ? "on" : ""} onClick={() => setDevice("desktop")}>🖥 桌機</button>
          <button className={device === "mobile" ? "on" : ""} onClick={() => setDevice("mobile")}>📱 手機</button>
        </div>
        <label className="toggle"><input type="checkbox" checked={anno} onChange={e => setAnno(e.target.checked)} /> API 註記</label>
      </div>
    </div>

    <div className="legend">
      <span><span className="anno">GET /api/…</span> 端點呼叫</span>
      <span><span className="anno m">POST /api/…</span> 寫入 / 動作</span>
      <span><span className="bind">field</span> render 對應欄位</span>
      <span className="muted">· 桌機=A/B/C 分頁切換　手機=三案並排對照</span>
    </div>

    <div className="pagerail">
      {PAGES.map((p, i) =>
        <div key={i} className={"ptab" + (i === page ? " on" : "")} onClick={() => setPage(i)}>
          <span className="n">{String(i + 1).padStart(2, "0")}</span>{TAB_LABELS[i]}
        </div>)}
    </div>

    <div className="pintro">
      <div style={{ flex: 1, minWidth: 280 }}>
        <div className="row center gap12 wrap"><h2>{P.title}</h2><span className="path mono">{P.path}</span></div>
        <p>{P.desc}</p>
      </div>
    </div>

    {device === "desktop" &&
      <div className="vtabs">
        {P.variants.map((v, i) =>
          <div key={i} className={"vtab" + (i === variant ? " on" : "")} onClick={() => setVariant(i)}>
            <b>方案 {v.tag}</b><span>{v.cap}</span>
          </div>)}
      </div>}

    <Stage device={device} url={P.path} variants={P.variants} active={variant} />
  </div>;
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
