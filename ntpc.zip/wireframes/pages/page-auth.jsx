/* 3.1 register.php + 3.2 login.php */
window.PAGE_auth = {
  path: "/pages/login.php · register.php",
  title: "登入 / 註冊",
  desc: "強制登入才能用站。register（username 3-50、password ≥8）成功自動登入跳首頁；login 失敗顯示「帳號或密碼錯誤」。舊 login.php 假登入邏輯必須砍掉。",
  variants: [
    {
      tag: "A", cap: "置中單卡，登入/註冊用 tab 切換",
      render: (m) => <div className="screenpad" style={{ display: "flex", justifyContent: "center" }}>
        <div className="sk" style={{ width: m === "m" ? "100%" : 380, padding: 22 }}>
          <div className="row center" style={{ flexDirection: "column", gap: 4, marginBottom: 14 }}>
            <div className="ph plain" data-l="LOGO" style={{ width: 48, height: 48, borderRadius: 10 }} />
            <b className="hand" style={{ fontSize: 20 }}>新北美食地圖</b>
            <span className="lbl">登入後開始探索</span>
          </div>
          <div className="seg" style={{ width: "100%", marginBottom: 16 }}>
            <button className="on" style={{ flex: 1 }}>登入</button><button style={{ flex: 1 }}>註冊</button>
          </div>
          <span className="lbl">帳號 username</span>
          <div className="sk-flat" style={{ padding: "9px 12px", margin: "4px 0 12px" }}><span className="muted hand">3–50 字</span></div>
          <span className="lbl">密碼 password</span>
          <div className="sk-flat" style={{ padding: "9px 12px", margin: "4px 0 16px" }}><span className="muted hand">••••••• (≥8)</span></div>
          <Btn pri style={{ width: "100%", justifyContent: "center" }}>登入</Btn>
          <ARow style={{ marginTop: 12 }}>
            <A m>POST /api/auth/login</A><A m>POST /api/auth/register</A>
          </ARow>
          <ARow style={{ marginTop: 5 }}>
            <Bind>成功 → 跳 /pages/index.php</Bind><Bind>conflict → 帳號已存在</Bind>
          </ARow>
        </div>
      </div>
    },
    {
      tag: "B", cap: "左右分割：左品牌插圖、右表單（桌機）",
      render: (m) => <div className="row" style={{ minHeight: 320 }}>
        <div className="ph plain hide-m" data-l="品牌插圖 / 美食拼貼" style={{ flex: "0 0 46%", borderRadius: 0, borderWidth: "0 2px 0 0" }} />
        <div className="grow screenpad" style={{ display: "flex", flexDirection: "column", justifyContent: "center" }}>
          <b className="hand" style={{ fontSize: 22, marginBottom: 4 }}>建立帳號</b>
          <span className="lbl" style={{ marginBottom: 14 }}>已經有帳號了？<u>登入</u></span>
          <span className="lbl">username</span>
          <div className="sk-flat" style={{ padding: "10px 12px", margin: "4px 0 12px" }}><span className="muted hand">3–50 字</span></div>
          <span className="lbl">password</span>
          <div className="sk-flat" style={{ padding: "10px 12px", margin: "4px 0 6px" }}><span className="muted hand">至少 8 字</span></div>
          <span className="lbl" style={{ fontSize: 11, marginBottom: 14 }}>密碼一律 bcrypt 後端處理</span>
          <Btn pri style={{ width: "100%", justifyContent: "center" }}>註冊並登入</Btn>
          <ARow style={{ marginTop: 12 }}><A>POST /api/auth/register</A><Bind>成功自動 login</Bind></ARow>
        </div>
      </div>
    },
    {
      tag: "C", cap: "全幅地圖底 + 浮起登入 sheet",
      render: (m) => <div className="ph plain" data-l="全幅新北地圖底圖" style={{ height: m === "m" ? 520 : 360, borderRadius: 0, position: "relative", justifyContent: "center", alignItems: "flex-end", padding: m === "m" ? 0 : 24 }}>
        <div className="sk" style={{ width: m === "m" ? "100%" : 400, background: "#fff", padding: 22, alignSelf: m === "m" ? "stretch" : "center", margin: m === "m" ? "auto 10px" : 0 }}>
          <b className="hand" style={{ fontSize: 19 }}>歡迎回來 👋</b>
          <div style={{ marginTop: 14 }}>
            <div className="sk-flat" style={{ padding: "10px 12px", marginBottom: 10 }}><span className="muted hand">username</span></div>
            <div className="sk-flat" style={{ padding: "10px 12px", marginBottom: 14 }}><span className="muted hand">password ••••••</span></div>
            <Btn pri style={{ width: "100%", justifyContent: "center" }}>登入</Btn>
            <div className="row between" style={{ marginTop: 10 }}>
              <span className="lbl" style={{ fontSize: 12 }}>沒有帳號？<u>註冊</u></span>
              <span className="lbl" style={{ fontSize: 12, color: "var(--accent)" }}>帳號或密碼錯誤</span>
            </div>
          </div>
          <ARow style={{ marginTop: 12 }}><A m>POST /api/auth/login</A></ARow>
        </div>
      </div>
    }
  ]
};
