/* 3.8 admin.php 後台。餐廳管理 + 使用者管理（super admin user_id=1 保護） */
function AdminRow({ cols, disabled, m }) {
  return <div className="row center" style={{ padding: "8px 10px", borderBottom: "1px dashed var(--paper-edge)", opacity: disabled ? .5 : 1, gap: 8 }}>
    {cols}
  </div>;
}

window.PAGE_admin = {
  path: "/pages/admin.php",
  title: "Admin 後台",
  desc: "開頁 GET /api/auth/me 確認 is_admin=1，否則跳首頁。兩分頁：餐廳管理（CRUD + 照片）/ 使用者管理（promote/demote/delete）。user_id=1 那列三鈕全 disable。操作前都 confirm。",
  variants: [
    {
      tag: "A", cap: "頂部分頁 tab + 資料表格 + 右側編輯抽屜",
      render: (m) => <div className="screenpad">
        <div className="row between center wrap gap8" style={{ marginBottom: 12 }}>
          <div className="seg"><button className="on">餐廳管理</button><button>使用者管理</button></div>
          <Btn pri sm>+ 新增餐廳</Btn>
        </div>
        <div className="sk" style={{ overflow: "hidden" }}>
          <div className="row center" style={{ padding: "8px 10px", background: "var(--paper2)", borderBottom: "2px solid var(--ink)", fontSize: 12, gap: 8 }}>
            <b className="hand grow">餐廳名稱</b><b className="hand hide-m" style={{ width: 70 }}>區</b><b className="hand" style={{ width: 50 }}>評分</b><b className="hand" style={{ width: 90, textAlign: "right" }}>操作</b>
          </div>
          {Array.from({ length: 5 }).map((_, i) => <AdminRow key={i} cols={<>
            <span className="hand grow" style={{ fontSize: 14 }}>蘇義興餐廳</span>
            <span className="lbl hide-m" style={{ width: 70 }}>板橋</span>
            <span className="lbl" style={{ width: 50 }}>4.2</span>
            <div style={{ width: 90, textAlign: "right" }} className="row gap6"><Btn sm>編輯</Btn><Btn sm>刪</Btn></div>
          </>} />)}
        </div>
        <ARow style={{ marginTop: 8 }}>
          <A>GET /api/restaurants/list?limit=50&offset=</A><A m>POST /api/admin/restaurant/upsert · /delete</A>
        </ARow>
        <Note>編輯 row → 載 detail 預填表單；zipcode 下拉=dicts/districts、tags=dicts/tags multi-select；照片可新增 url / 設 main / 刪</Note>
      </div>
    },
    {
      tag: "B", cap: "使用者管理：super admin 列鈕全 disable",
      render: (m) => <div className="screenpad">
        <div className="seg" style={{ marginBottom: 12 }}><button>餐廳管理</button><button className="on">使用者管理</button></div>
        <div className="sk-flat row center" style={{ padding: "6px 10px", marginBottom: 10 }}><span className="muted hand grow">🔍 搜尋帳號</span></div>
        <div className="sk" style={{ overflow: "hidden" }}>
          <div className="row center" style={{ padding: "8px 10px", background: "var(--paper2)", borderBottom: "2px solid var(--ink)", fontSize: 12, gap: 8 }}>
            <b className="hand" style={{ width: 36 }}>id</b><b className="hand grow">username</b><b className="hand hide-m" style={{ width: 60 }}>評論</b><b className="hand" style={{ width: 130, textAlign: "right" }}>操作</b>
          </div>
          <AdminRow disabled cols={<>
            <span className="mono" style={{ width: 36 }}>1</span>
            <span className="hand grow" style={{ fontSize: 14 }}>admin <span className="badge" style={{ fontSize: 10 }}>super</span></span>
            <span className="lbl hide-m" style={{ width: 60 }}>—</span>
            <div style={{ width: 130, textAlign: "right" }} className="row gap6"><Btn sm>promote</Btn><Btn sm>del</Btn></div>
          </>} />
          {[2, 3, 4].map(id => <AdminRow key={id} m={m} cols={<>
            <span className="mono" style={{ width: 36 }}>{id}</span>
            <span className="hand grow" style={{ fontSize: 14 }}>{["alice", "bob", "carol"][id - 2]} {id === 3 && <span className="badge">admin</span>}</span>
            <span className="lbl hide-m" style={{ width: 60 }}>{id * 3}</span>
            <div style={{ width: 130, textAlign: "right" }} className="row gap6">
              <Btn sm>{id === 3 ? "demote" : "promote"}</Btn><Btn sm>del</Btn>
            </div>
          </>} />)}
        </div>
        <ARow style={{ marginTop: 8 }}>
          <A>GET /api/admin/users/list</A><A m>POST promote / demote / delete</A>
          <Bind>user_id=1 → 三鈕 disable（後端再擋）</Bind>
        </ARow>
        <Note>每個操作前 confirm dialog</Note>
      </div>
    },
    {
      tag: "C", cap: "新增 / 編輯餐廳表單（含照片管理）",
      render: (m) => <div className="screenpad">
        <div className="row between center" style={{ marginBottom: 10 }}><b className="hand" style={{ fontSize: 18 }}>編輯餐廳 #1</b><Btn sm>← 返回列表</Btn></div>
        <div className="row gap16" style={{ flexDirection: m === "m" ? "column" : "row" }}>
          <div className="grow col gap10">
            {["餐廳名稱", "描述", "地址"].map(l => <div key={l}><span className="lbl">{l}</span><div className="sk-flat" style={{ padding: "8px 10px", marginTop: 3 }}><span className="muted hand">…</span></div></div>)}
            <div className="row gap8">
              <div className="grow"><span className="lbl">區 zipcode ▾</span><div className="sk-flat" style={{ padding: "8px 10px", marginTop: 3 }}><span className="muted hand">板橋 220 ▾</span></div></div>
              <div className="grow"><span className="lbl">價位</span><div className="sk-flat" style={{ padding: "8px 10px", marginTop: 3 }}><span className="muted hand">$$ ▾</span></div></div>
            </div>
            <div><span className="lbl">分類 tags（multi）</span><div className="row wrap gap6" style={{ marginTop: 4 }}><Chip on>小吃</Chip><Chip on>熱炒</Chip><Chip>+ 加</Chip></div></div>
            <ARow><A>dicts/districts</A><A>dicts/tags</A></ARow>
          </div>
          <div style={{ flex: m === "m" ? "none" : "0 0 220px" }}>
            <span className="lbl">照片管理</span>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6, marginTop: 6 }}>
              {Array.from({ length: 4 }).map((_, i) => <div key={i} style={{ position: "relative" }}>
                <Ph label="" plain h={56} r={6} style={{ borderColor: i === 0 ? "var(--accent)" : "var(--ink)" }} />
                {i === 0 && <span className="badge" style={{ position: "absolute", top: 3, left: 3, fontSize: 9 }}>main</span>}
              </div>)}
              <div className="sk-flat" style={{ height: 56, display: "flex", alignItems: "center", justifyContent: "center" }}><span className="hand muted">+ url</span></div>
            </div>
            <ARow style={{ marginTop: 6 }}><A m>photo/upsert · /delete</A></ARow>
          </div>
        </div>
        <div className="row gap8" style={{ marginTop: 14 }}><Btn pri>儲存</Btn><Btn>取消</Btn></div>
        <ARow style={{ marginTop: 8 }}><A m>POST /api/admin/restaurant/upsert（transaction）</A></ARow>
      </div>
    }
  ]
};
