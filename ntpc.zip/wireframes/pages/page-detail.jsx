/* 3.6 detail.php 詳情頁。6 圖切換 + 完整資訊 + 評論 */
function OpenTable() {
  const days = ["一", "二", "三", "四", "五", "六", "日"];
  return <div className="sk-flat" style={{ padding: 10 }}>
    {days.map((d, i) => <div key={i} className="row between" style={{ padding: "3px 2px", borderBottom: i < 6 ? "1px dashed var(--paper-edge)" : "none" }}>
      <span className="hand" style={{ fontSize: 13 }}>週{d}</span>
      <span className="lbl mono" style={{ fontSize: 12 }}>{i === 4 ? "公休" : "11:00–21:00"}</span>
    </div>)}
  </div>;
}
function ReviewItem() {
  return <div className="sk-flat" style={{ padding: "10px 12px" }}>
    <div className="row between center">
      <div className="row center gap6"><div className="ph plain" data-l="" style={{ width: 26, height: 26, borderRadius: 50 }} /><b className="hand" style={{ fontSize: 14, textDecoration: "underline" }}>alice</b><span className="lbl" style={{ fontSize: 11 }}>· 7 則評論</span></div>
      <Stars n={5} size={12} />
    </div>
    <Bars lines={2} w={["100%", "66%"]} style={{ marginTop: 6 }} />
    <span className="lbl mono" style={{ fontSize: 10 }}>2025-11-02</span>
  </div>;
}
function InfoBlock({ m }) {
  return <div>
    <div className="row between center">
      <b className="hand" style={{ fontSize: m === "m" ? 20 : 24 }}>蘇義興餐廳</b>
      <div className="row center gap8"><Badge kind="open">營業中</Badge><Heart on /></div>
    </div>
    <div className="row center gap8" style={{ margin: "6px 0" }}>
      <Stars n={4} /><b className="hand">4.2</b><span className="lbl">(15 則)</span><span className="lbl">· $$ · 板橋區</span>
    </div>
    <ARow><Bind>rating_avg</Bind><Bind>rating_count</Bind><Bind>is_open_now</Bind><Bind>is_favorited</Bind><Bind>price_level</Bind></ARow>
    <div className="row wrap gap6" style={{ margin: "10px 0" }}><Chip>小吃／熱炒</Chip><Chip>台菜</Chip><Chip>📞 02-1234-5678</Chip></div>
    <Bars lines={2} w={["100%", "88%"]} />
  </div>;
}

window.PAGE_detail = {
  path: "/pages/detail.php?id=",
  title: "詳情頁",
  desc: "GET /api/restaurants/detail?id= 一次拿全。照片 1~6 動態（只一張不顯示箭頭/縮圖）。營業表用 opentime_regular、特殊用 opentime_special。徽章直接讀 is_open_now。評論 upsert（已有則預填變「更新」）。",
  variants: [
    {
      tag: "A", cap: "大圖 + 下方縮圖列（左右箭頭）· 經典 gallery",
      render: (m) => <div className="screenpad">
        <div className="row gap16" style={{ flexDirection: m === "m" ? "column" : "row" }}>
          <div style={{ flex: m === "m" ? "none" : "0 0 52%" }}>
            <div style={{ position: "relative" }}>
              <Ph label="大圖 photos[i]" h={m === "m" ? 200 : 280} />
              <div className="btn sm" style={{ position: "absolute", top: "50%", left: 8, transform: "translateY(-50%)", background: "#fff" }}>‹</div>
              <div className="btn sm" style={{ position: "absolute", top: "50%", right: 8, transform: "translateY(-50%)", background: "#fff" }}>›</div>
              <span className="badge" style={{ position: "absolute", bottom: 8, right: 8 }}>2 / 6</span>
            </div>
            <div className="row gap6" style={{ marginTop: 8 }}>
              {Array.from({ length: 6 }).map((_, i) => <Ph key={i} label="" plain h={46} w={46} r={6} style={{ borderWidth: i === 1 ? 2 : 1.5, borderColor: i === 1 ? "var(--accent)" : "var(--ink)" }} />)}
            </div>
            <ARow style={{ marginTop: 6 }}><Bind>photos[] 動態 1~6</Bind><Note>只 1 張 → 不顯示箭頭/縮圖</Note></ARow>
          </div>
          <div className="grow"><InfoBlock m={m} /></div>
        </div>
        <DetailLower m={m} />
      </div>
    },
    {
      tag: "B", cap: "全幅 hero 大圖 + 縮圖浮在右下 · 沉浸式",
      render: (m) => <div>
        <div style={{ position: "relative" }}>
          <Ph label="全幅主圖 photos[0]" h={m === "m" ? 220 : 320} r={0} />
          <div className="row gap6" style={{ position: "absolute", bottom: 10, right: 10 }}>
            {Array.from({ length: 4 }).map((_, i) => <Ph key={i} label="" plain h={40} w={40} r={6} style={{ borderColor: "#fff", borderWidth: i === 0 ? 2.5 : 1.5 }} />)}
            <span className="badge" style={{ alignSelf: "center" }}>+2</span>
          </div>
          <div className="btn sm" style={{ position: "absolute", top: "50%", left: 10, transform: "translateY(-50%)", background: "#fff" }}>‹</div>
          <div className="btn sm" style={{ position: "absolute", top: "50%", right: 10, transform: "translateY(-50%)", background: "#fff" }}>›</div>
        </div>
        <div className="screenpad"><InfoBlock m={m} /><DetailLower m={m} /></div>
      </div>
    },
    {
      tag: "C", cap: "縮圖直列在左 + 大圖在右 · 桌機畫廊",
      render: (m) => <div className="screenpad">
        <div className="row gap12">
          <div className="col gap6 hide-m" style={{ flex: "0 0 56px" }}>
            {Array.from({ length: 6 }).map((_, i) => <Ph key={i} label="" plain h={48} w={48} r={6} style={{ borderColor: i === 0 ? "var(--accent)" : "var(--ink)", borderWidth: i === 0 ? 2 : 1.5 }} />)}
          </div>
          <div className="grow" style={{ position: "relative" }}>
            <Ph label="大圖 photos[i]" h={m === "m" ? 200 : 300} />
            <span className="badge" style={{ position: "absolute", bottom: 8, right: 8 }}>1 / 6</span>
          </div>
        </div>
        <div className="show-m row gap6" style={{ marginTop: 8 }}>
          {Array.from({ length: 6 }).map((_, i) => <Ph key={i} label="" plain h={40} w={40} r={6} />)}
        </div>
        <div style={{ marginTop: 14 }}><InfoBlock m={m} /></div>
        <DetailLower m={m} />
      </div>
    }
  ]
};

function DetailLower({ m }) {
  return <div>
    <ARow style={{ marginTop: 6 }}><A m>GET /api/restaurants/detail?id=</A></ARow>
    <div className="row gap16" style={{ flexDirection: m === "m" ? "column" : "row", marginTop: 12 }}>
      <div className="grow">
        <SecH>營業資訊 opentime_regular</SecH><OpenTable />
        <div style={{ marginTop: 8 }}><span className="lbl">特殊營業 opentime_special</span>
          <div className="row wrap gap6" style={{ marginTop: 6 }}><Chip>週五公休</Chip><Chip>農曆春節休</Chip></div></div>
      </div>
      <div className="grow">
        <SecH>寫評論</SecH>
        <div className="sk-flat" style={{ padding: 12 }}>
          <div className="row center gap6" style={{ marginBottom: 8 }}><span className="lbl">評分</span><Stars n={0} size={20} /></div>
          <div className="sk-flat" style={{ padding: 10, minHeight: 56 }}><span className="muted hand">分享你的用餐心得…（≤1000 字）</span></div>
          <div className="row between center" style={{ marginTop: 8 }}>
            <span className="lbl" style={{ fontSize: 11 }}>已有評論 → 預填、按鈕變「更新」</span>
            <Btn pri sm>送出評論</Btn>
          </div>
          <ARow style={{ marginTop: 8 }}><A m>POST /api/reviews/upsert</A><Bind>未登入→請先登入</Bind><Bind>user_review 預填</Bind></ARow>
        </div>
      </div>
    </div>
    <SecH>評論列表</SecH>
    <div className="col gap8"><ReviewItem /><ReviewItem /></div>
    <ARow style={{ marginTop: 8 }}>
      <A>GET /api/reviews/by_restaurant?restaurant_id=&limit=20&offset=0</A>
      <Bind>username→profile.php?id=</Bind><Bind>reviewer_total_reviews</Bind>
    </ARow>
  </div>;
}
