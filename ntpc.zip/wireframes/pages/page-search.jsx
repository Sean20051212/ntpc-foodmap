/* 3.4 search.php 搜尋 / 列表頁。左側篩選 + 右側卡片列表 + 分頁 */
function FilterPanel({ compact }) {
  return <div>
    <div className="filt-row">
      <div className="ft">多選區域 <span className="lbl" style={{ fontSize: 11 }}>板橋 +2</span></div>
      <div className="sk-flat row between center" style={{ padding: "7px 10px" }}><span className="muted hand">選擇區域 ▾</span></div>
      <ARow><A>GET /api/dicts/districts</A></ARow>
    </div>
    <div className="filt-row">
      <div className="ft">多選分類</div>
      <div className="row wrap gap6">
        <Chip on>小吃</Chip><Chip>火鍋</Chip><Chip>日式</Chip><Chip on>早午餐</Chip><Chip>+9</Chip>
      </div>
      <ARow><A>GET /api/dicts/tags（14）</A></ARow>
    </div>
    <div className="filt-row">
      <div className="ft">距離 <span className="lbl" style={{ fontSize: 11 }}>≤300m</span></div>
      <RangeBar pos={2} />
      <ARow><Bind>max_distance_m</Bind><Bind>需 user_lat/lng</Bind></ARow>
    </div>
    <div className="filt-row">
      <div className="ft">評分 <span className="lbl" style={{ fontSize: 11 }}>≥3★</span></div>
      <RangeBar scale={["不限", "1★", "2★", "3★", "4★"]} pos={3} />
      <ARow><Bind>min_rating</Bind></ARow>
    </div>
    <div className="sk-flat" style={{ background: "var(--accent-soft)", borderColor: "var(--accent)", padding: "8px 12px", textAlign: "center" }}>
      <b className="hand">找到 <span style={{ color: "var(--accent)" }}>23</span> 家</b>
    </div>
    <ARow style={{ marginTop: 6 }}><A m>條件變動 debounce300ms → GET /api/restaurants/count</A></ARow>
    <Btn pri style={{ width: "100%", justifyContent: "center", marginTop: 8 }}>搜尋</Btn>
  </div>;
}

function ListCard({ row, m }) {
  if (row) return <div className="wcard row" style={{ alignItems: "stretch" }}>
    <Ph label="main_photo_url" w={m === "m" ? 96 : 140} h="auto" r={0} style={{ borderWidth: 0, flex: "0 0 " + (m === "m" ? 96 : 140) + "px" }} />
    <div style={{ padding: "10px 12px", flex: 1 }}>
      <div className="row between center">
        <b className="hand" style={{ fontSize: 16 }}>蘇義興餐廳</b>
        <div className="row center gap6"><Badge kind="open">營業中</Badge><Heart /></div>
      </div>
      <div className="row center gap8" style={{ margin: "3px 0" }}>
        <Stars n={4} size={13} /><span className="lbl" style={{ fontSize: 12 }}>4.2 (15)</span>
        <span className="lbl" style={{ fontSize: 12 }}>· 320m · $$</span>
      </div>
      <div className="row wrap gap6"><Chip>小吃</Chip><Chip>熱炒</Chip></div>
      <ARow style={{ marginTop: 6 }}>
        <Bind>distance_m</Bind><Bind>is_open_now</Bind><Bind>price_level</Bind>
      </ARow>
    </div>
  </div>;
  return <div className="wcard">
    <div style={{ position: "relative" }}>
      <Ph label="main_photo_url" h={110} r={0} style={{ borderWidth: 0 }} />
      <div style={{ position: "absolute", top: 8, right: 8 }}><Heart /></div>
      <div style={{ position: "absolute", top: 8, left: 8 }}><Badge kind="open">營業中</Badge></div>
    </div>
    <div style={{ padding: 10 }}>
      <b className="hand" style={{ fontSize: 15 }}>蘇義興餐廳</b>
      <div className="row center gap6" style={{ margin: "2px 0" }}><Stars n={4} size={12} /><span className="lbl" style={{ fontSize: 11 }}>4.2 · 320m</span></div>
      <div className="row wrap gap6"><Chip>小吃</Chip><Chip>$$</Chip></div>
    </div>
  </div>;
}

window.PAGE_search = {
  path: "/pages/search.php",
  title: "搜尋 / 列表頁",
  desc: "開頁 POST /api/geo/locate；in_ntpc=false → nearby_ntpc。左篩選任何條件變動 debounce300ms → count；按搜尋 → list。右側卡片 + 分頁。前端不自行 filter/sort/paginate。",
  variants: [
    {
      tag: "A", cap: "固定左欄篩選 + 右側雙欄網格卡（OpenRice 風）",
      render: (m) => <div className="row" style={{ minHeight: 360 }}>
        <div className="hide-m" style={{ flex: "0 0 232px", borderRight: "2px solid var(--ink)", padding: 14, background: "var(--paper2)" }}>
          <SecH>篩選</SecH><FilterPanel />
        </div>
        <div className="grow screenpad">
          <div className="sk-flat row center" style={{ padding: "6px 10px", marginBottom: 10 }}><span className="muted hand grow">🔍 搜尋餐廳 / 地址</span><Btn sm>排序 ▾</Btn></div>
          <div className="show-m" style={{ marginBottom: 10 }}><Btn sm>⚙ 篩選 (4)</Btn> <span className="badge">找到 23 家</span></div>
          <div className="row between center" style={{ marginBottom: 8 }}>
            <span className="lbl">23 家 · 板橋 + 鄰接</span><span className="lbl" style={{ fontSize: 12 }}>sort: rating_desc</span>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: m === "m" ? "1fr 1fr" : "1fr 1fr 1fr", gap: 12 }}>
            {Array.from({ length: 6 }).map((_, i) => <ListCard key={i} m={m} />)}
          </div>
          <ARow style={{ marginTop: 10 }}>
            <A m>GET /api/restaurants/list?district[]=&tag[]=&sort=&limit=&offset=</A>
          </ARow>
          <div className="row center gap6" style={{ justifyContent: "center", marginTop: 12 }}>
            <Chip>‹</Chip><Chip on>1</Chip><Chip>2</Chip><Chip>3</Chip><Chip>›</Chip>
          </div>
        </div>
      </div>
    },
    {
      tag: "B", cap: "篩選收合為頂部 chips bar + 寬鬆橫式卡列表",
      render: (m) => <div className="screenpad">
        <div className="sk-flat row center" style={{ padding: "6px 10px", marginBottom: 10 }}><span className="muted hand grow">🔍 搜尋…</span><Btn sm pri>搜尋</Btn></div>
        <div className="row wrap gap6 center" style={{ marginBottom: 4 }}>
          <Btn sm>區域 ▾</Btn><Btn sm>分類 ▾</Btn>
          <div className="row center gap6"><span className="lbl" style={{ fontSize: 12 }}>距離</span><div style={{ width: 120 }}><RangeBar pos={2} /></div></div>
          <Chip on>≥3★</Chip>
          <span className="badge" style={{ marginLeft: "auto" }}>找到 23 家</span>
        </div>
        <ARow style={{ marginBottom: 10 }}><A>變動 → debounce300ms → /count</A><Bind>展開下拉才 call dicts</Bind></ARow>
        <div className="col gap10">
          {Array.from({ length: 4 }).map((_, i) => <ListCard key={i} row m={m} />)}
        </div>
        <ARow style={{ marginTop: 10 }}><A m>GET /api/restaurants/list</A></ARow>
        <div className="row center" style={{ justifyContent: "center", marginTop: 12 }}><Btn>載入更多 / 下一頁</Btn></div>
      </div>
    },
    {
      tag: "C", cap: "三欄：篩選 + 列表 + 即時迷你地圖（list↔map 橋接）",
      render: (m) => <div className="row" style={{ minHeight: 360 }}>
        <div className="hide-m" style={{ flex: "0 0 200px", borderRight: "2px solid var(--ink)", padding: 12, background: "var(--paper2)" }}>
          <SecH>篩選</SecH><FilterPanel compact />
        </div>
        <div className="grow screenpad">
          <div className="show-m" style={{ marginBottom: 8 }}><Btn sm>⚙ 篩選</Btn></div>
          <span className="lbl">23 家</span>
          <div className="col gap10" style={{ marginTop: 8 }}>
            {Array.from({ length: 3 }).map((_, i) => <ListCard key={i} row m={m} />)}
          </div>
          <ARow style={{ marginTop: 8 }}><A m>GET /api/restaurants/list</A></ARow>
        </div>
        <div className="hide-m" style={{ flex: "0 0 240px", borderLeft: "2px solid var(--ink)" }}>
          <Ph label="迷你地圖（hover 卡片 → 跳 marker）" h="100%" r={0} style={{ borderWidth: 0, minHeight: 360 }} />
        </div>
      </div>
    }
  ]
};
